"""Etude A01, geometrique uniquement. Executer avec le Python livre avec FreeCAD.
Reprend la version32 archivee, sans modifier la presentation originale.
"""
import os, sys, json, math, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'Controle-A01'
OUT.mkdir(exist_ok=True)
os.chdir(ROOT)
import FreeCAD as App
import Part, Mesh
V=App.Vector
data=json.loads((ROOT/'geometrie32.json').read_text(encoding='utf8'))
report={'source':'virtualvisionlabs/bivouac-pat @ ea4a1978db2e5e964ccdbc9c384a788d178b2e38 / complet-32.html',
        'unite':'mm','statut':'ETUDE GEOMETRIQUE - PAS UN BON POUR FABRICATION', 'validite':{},'constats':{}}
doc=App.newDocument('BIVOUAC_Controle_A01')
sheet=doc.addObject('Spreadsheet::Sheet','Parametres')
for r,values in enumerate([
 ['BIVOUAC - Controle A01','mm / proposition non validee'],
 ['Pivot X',-50],['Pivot Y',0],['Diametre axe indicatif',5],['Alesage lame source',5.1],
 ['Epaisseur lame source',2],['Face interieure platine arriere',-1.25],['Face interieure platine avant',1.065],
 ['Decalage lame propose',-0.0925],['Rondelle proposee (chaque cote)',0.1],['Jeu axial restant total',0.115],
 ['Rondelle : diametre interieur',5.1],['Rondelle : diametre exterieur',6.8],
 ['Coques exterieures source','-7.7 a +7.7'],['Attention','Pas de tolerance de fabrication attribuee'],
 ['Pivot commercial','A choisir AVANT validation des percages'],
 ['Loquet et butees','Illustration source - a concevoir / valider'],
 ],1):
 for c,value in zip(('A','B'),values): sheet.set(c+str(r),str(value))
sheet.setColumnWidth('A',270);sheet.setColumnWidth('B',350)
ref=doc.addObject('App::DocumentObjectGroup','Reference32');ref.Label='01 - Reference 32 (maillages, non usinable)'
orig=doc.addObject('App::DocumentObjectGroup','SolidesOrigine');orig.Label='02 - Pieces source reconstruites en solides'
prop=doc.addObject('App::DocumentObjectGroup','EtudeAjustement');prop.Label='03 - Proposition de centrage (a valider)'
def mesh_for(i):
 d=data[i];a=d['vertices'];pts=[tuple(a[j:j+3]) for j in range(0,len(a),3)]
 ix=d['indices'] or list(range(len(pts)))
 return Mesh.Mesh([[pts[ix[j+k]] for k in range(3)] for j in range(0,len(ix),3)])
def solid_for(i,repair=False):
 if repair and i in (47,48,49):
  # Reconstitution CAO explicite du contour moins le logement traversant.
  # Ce sont de NOUVEAUX solides proposes, pas une reparation invisible de la source.
  pts=[(65,-8.5),(-46,-8.5),(-48,-6),(-48,6),(-46,8.5),(65,8.5),(65,-8.5)]
  pocket=Part.Face(Part.makePolygon([V(x,y,0) for x,y in pts]))
  section=face.cut(pocket)
  lo,hi={47:(2.6,3.1),48:(6.4,7.7),49:(3.1,6.4)}[i]
  s=section.extrude(V(0,0,hi-lo));s.translate(V(0,0,lo));s=s.removeSplitter()
  rounding='sans conge supplementaire'
  if i==48:
   try:
    edges=[e for e in s.Edges if abs(e.BoundBox.ZMin-hi)<1e-6 and abs(e.BoundBox.ZMax-hi)<1e-6]
    s=s.makeFillet(.15,edges);rounding='conge superieur propose 0.15'
   except Exception:rounding='conge non applique - forme a valider'
  report.setdefault('reconstruction_coques',{})[str(i)]={'methode':'Contour source moins logement interieur reconstruit en CAO','finition':rounding,'valide':s.isValid()}
  return s
 m=mesh_for(i);s=Part.Shape();s.makeShapeFromMesh(m.Topology,0.00001)
 shells=s.Shells
 if len(shells)!=1 or not shells[0].isClosed(): raise ValueError(f'Maillage {i}: pas une coque unique fermee')
 s=Part.makeSolid(shells[0]);s=s.removeSplitter()
 if s.Volume<0:s.reverse()
 return s
def feature(name,label,shape,group,color=(0.7,0.73,0.74)):
 o=doc.addObject('PartDesign::Feature',name);o.Label=label;o.Shape=shape;group.addObject(o)
 o.addProperty('App::PropertyString','Statut','Provenance');o.Statut='Etude de geometrie, non autorise pour fabrication'
 if App.GuiUp: o.ViewObject.ShapeColor=color
 report['validite'][name]={'valide':shape.isValid(),'solides':len(shape.Solids),'volume_mm3':shape.Volume}
 return o
def wire_from(curves,dx=0,z=0):
 edges=[]
 for c in curves:
  def point(key):return V(c[key][0]+dx,c[key][1],z)
  typ=c['type']
  if typ=='LineCurve': edges.append(Part.makeLine(point('v1'),point('v2')))
  elif typ in ('QuadraticBezierCurve','CubicBezierCurve'):
   curve=Part.BezierCurve();curve.setPoles([point('v'+str(i)) for i in range(3 if typ=='QuadraticBezierCurve' else 4)]);edges.append(curve.toShape())
  else:raise ValueError(typ)
 return Part.Wire(edges)
blade_outline=wire_from(data[4]['parameters']['shapes']['curves'],-50,-1)
stock=Part.Face(blade_outline).extrude(V(0,0,2))
bore=Part.makeCylinder(2.55,4,V(-50,0,-2))
blade=stock.cut(bore).removeSplitter()
blade_obj=feature('LameSource','Lame source - epaisseur pleine, sans emouture usinee',blade,orig)
profile=wire_from(data[1]['parameters']['shapes']['curves'])
face=Part.Face(profile)
rear=face.extrude(V(0,0,.65));rear.translate(V(0,0,-1.9));rear=rear.cut(Part.makeCylinder(2.5,4,V(-50,0,-2)))
front=face.extrude(V(0,0,1.27));front.translate(V(0,0,1.065))
front=front.cut(Part.makeCylinder(2.5,5,V(-50,0,-2))).cut(Part.makeBox(59.05,14.2,5,V(-47,-16,0))).removeSplitter()
front_obj=feature('PlatineAvantSource','Platine avant source (decoupe illustrative du verrou)',front,orig)
rear_obj=feature('PlatineArriereSource','Platine arriere source',rear,orig)
# Importer TOUTES les autres pieces comme references, sans les faire passer pour de la CAO d'usinage.
for i,d in enumerate(data):
 if i in (0,1,4) or not d['visible']:continue
 o=doc.addObject('Mesh::Feature','Ref%03d'%i);o.Label=d['name'] or 'Ancrage illustratif';o.Mesh=mesh_for(i);ref.addObject(o)
 if App.GuiUp:
  o.ViewObject.ShapeColor=(.18,.27,.23) if 'Plaquette' in d['path'] and 'Vis' not in d['name'] else (.65,.69,.7)
  if 'orange' in d['name'].lower():o.ViewObject.ShapeColor=(.9,.42,.16)
shift=-.0925
candidate=blade.copy();candidate.translate(V(0,0,shift))
candidate_obj=feature('LameCentree','Lame recentree - proposition A01',candidate,prop,(.75,.77,.8))
candidate_obj.addProperty('App::PropertyDistance','DecalageZ','Etude');candidate_obj.DecalageZ=shift
def washer(z):return Part.makeCylinder(3.4,.1,V(-50,0,z)).cut(Part.makeCylinder(2.55,.1,V(-50,0,z)))
wb=washer(-1.1925);wf=washer(.9075)
rear_w=feature('RondelleArriere','Rondelle arriere - enveloppe hypothetique 0.10',wb,prop,(.75,.53,.2))
front_w=feature('RondelleAvant','Rondelle avant - enveloppe hypothetique 0.10',wf,prop,(.75,.53,.2))
# Axe long de CONTROLE : ni filetage ni quincaillerie commercialement definie.
axis=Part.makeCylinder(2.5,15.4,V(-50,0,-7.7))
axis_obj=feature('AxeControle','Enveloppe de controle du pivot traversant - NON une vis definie',axis,prop,(.9,.35,.1))
# Comparer la future traverse aux pieces source, sans agrandir les trous a l'aveugle.
tests=[]
for i in [46,47,48,49,50,54,55,115,116,117,125,126,127,128,129,156,157]:
 try:
  s=solid_for(i);common=axis.common(s)
  tests.append({'index':i,'piece':data[i]['name'],'valide':s.isValid(),'intersection_axe_mm3':round(common.Volume,7)})
 except Exception as e: tests.append({'index':i,'piece':data[i]['name'],'erreur':str(e)})
report['intersection_pivot_traversant']=tests
# Variante de travail : percer les coques et inserts autour du MEME axe.
# Les diametres sont provisoires tant que la quincaillerie n'est pas choisie.
shells=doc.addObject('App::DocumentObjectGroup','CoquesPercees');shells.Label='04 - Coques : passages concentriques proposes (provisoires)'
clearance=Part.makeCylinder(2.6,20,V(-50,0,-10))
cut_shells=[]
for i in [46,47,48,49,50,54,55,115,116,117]:
 try:
  s=solid_for(i,repair=True);intersection=s.common(clearance).Volume
  if intersection>0.000001:
   cut=s.cut(clearance).removeSplitter()
   o=feature('Passage%03d'%i,data[i]['name']+' - passage provisoire diametre 5.20',cut,shells,(.18,.27,.23))
   cut_shells.append(o)
   report.setdefault('passages_coques',[]).append({'index':i,'volume_retire_mm3':intersection,'volume_axe_apres_mm3':cut.common(axis).Volume})
   if App.GuiUp:doc.getObject('Ref%03d'%i).Visibility=False
 except Exception as e:report.setdefault('erreurs_percages',[]).append({'index':i,'erreur':str(e)})
report['constats']={'pivot_xy':[-50,0],'alesage_lame':5.1,'axe_indicatif':5,
 'jeu_diametral_source':.1,'jeu_axial_avant_source':.065,'jeu_axial_arriere_source':.25,
 'jeu_total_source':.315,'decalage_lame_propose':shift,'epaisseur_rondelles_proposee':.1,
 'jeu_avant_propose':.0575,'jeu_arriere_propose':.0575,
 'epaisseur_coques_inchangee':15.4,
 'rondelles_commentaire':'Dimensions de travail, ni reference commerciale ni tolerance validee.'}
# Balayage du contour de lame contre les platines fixes (loquet exclu : contact volontaire a concevoir).
sweep=[]
for angle in range(0,181,5):
 s=candidate.copy();s.rotate(V(-50,0,0),V(0,0,1),-angle)
 sweep.append({'angle_deg':angle,'volume_platine_avant':s.common(front).Volume,'volume_platine_arriere':s.common(rear).Volume})
report['balayage_platines_seulement']=sweep
report['non_verifie']=['Butées ouverte et fermée, résistance et contact du liner-lock',
 'Détente de fermeture et ressorts', 'Filetages et pivot commercial, fixation des coques',
 'Tolérances après traitement thermique et rectification', 'Balayage complet contre tous les accessoires',
 'Conformité à la maquette physique imprimée, non mesurée']
doc.recompute()
if App.GuiUp:
 orig.Visibility=False;prop.Visibility=True
 # References visibles, ancien axe/tetes caches pour montrer le principe du traversant.
 for i in (3,58,118):doc.getObject('Ref%03d'%i).Visibility=False
 doc.recompute()
doc.saveAs(str(OUT/'BIVOUAC-A01-controle.FCStd'))
Part.export([blade_obj,front_obj,rear_obj],str(OUT/'REFERENCE32-lame-et-platines.step'))
Part.export([candidate_obj,front_obj,rear_obj,rear_w,front_w,axis_obj],str(OUT/'ETUDE-A01-assemblage-pivot.step'))
if cut_shells:Part.export(cut_shells,str(OUT/'ETUDE-A01-passages-coques.step'))
# Relecture du STEP : controles d'echange, pas certification de fabrication.
for filename in ['REFERENCE32-lame-et-platines.step','ETUDE-A01-assemblage-pivot.step','ETUDE-A01-passages-coques.step']:
 s=Part.Shape();s.read(str(OUT/filename));report['validite'][filename]={'valide':s.isValid(),'solides':len(s.Solids),'volume_mm3':s.Volume}
(OUT/'mesures-et-controles.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('CONTROLE_A01_TERMINE',flush=True)
