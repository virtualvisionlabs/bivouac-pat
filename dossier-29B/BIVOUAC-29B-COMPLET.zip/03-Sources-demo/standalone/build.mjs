import {build} from 'esbuild';import fs from 'node:fs';
const out=await build({entryPoints:['standalone/main.ts'],bundle:true,write:false,format:'iife',platform:'browser',target:'es2020',minify:true,legalComments:'none'});
const html=fs.readFileSync('standalone/template.html','utf8').replace('__SCRIPT__',()=>out.outputFiles[0].text.replace(/<\/script/gi,'<\\/script'));
fs.writeFileSync('../BIVOUAC-Demonstration.html',html);console.log('HTML autonome : '+Buffer.byteLength(html)+' octets');
