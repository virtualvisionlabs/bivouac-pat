import {makeViewer} from '../app/viewer';
import {neutral,type ModelState} from '../app/model';
import {inspectionPose,inspectionSteps,type InspectionKind} from '../app/inspection';
let state:ModelState={...neutral,blade:true},timers:ReturnType<typeof setTimeout>[]=[],demo=false;
const $=(id:string)=>document.getElementById(id)!;
// Keep select values structural: the server Worker types also define Element.
const selectValue=(id:string)=>$(id) as unknown as {value:string};
try{
 const api=makeViewer($('scene') as HTMLDivElement);
 let manipulating=false,directOpen=false,directBack=false;
 let inspecting=false,kind:InspectionKind='fork',progress=0,playing=false,inside=false,speed=.5,clock=0,playback:ReturnType<typeof setInterval>|null=null;
 let panMode=false;
 $('camera-mode').onclick=()=>{panMode=!panMode;api.setPanMode(panMode);$('camera-mode').textContent=panMode?'Déplacer : actif':'Déplacer la vue';};
 $('pan-left').onclick=()=>api.panView(-1,0);$('pan-right').onclick=()=>api.panView(1,0);$('pan-up').onclick=()=>api.panView(0,1);$('pan-down').onclick=()=>api.panView(0,-1);$('camera-center').onclick=()=>api.recenter();
 const labels=(txt:string)=>$('message').textContent=txt;
 const clear=()=>{timers.forEach(clearTimeout);timers=[];demo=false;api.setPaused(false);};
 const pause=()=>{playing=false;if(playback!==null)clearInterval(playback);playback=null;$('play').textContent='▶ Lire';};
 const stopInspection=()=>{pause();inspecting=false;api.setInspection(null);$('inspection').hidden=true;$('normal-controls').hidden=false;$('views').hidden=false;$('inspect').hidden=false;};
 const stopDirect=()=>{if(!manipulating)return;api.disableDirect();manipulating=false;$('direct-controls').hidden=true;};
 const startDirect=()=>{panMode=false;api.setPanMode(false);$('camera-mode').textContent='Déplacer la vue';clear();pause();if(inspecting)stopInspection();stopDirect();manipulating=true;directOpen=false;directBack=false;api.resetCase();state={...neutral};api.setState(state);$('normal-controls').hidden=true;$('inspection').hidden=true;$('views').hidden=true;$('direct-controls').hidden=false;$('inspect').hidden=true;api.enableDirect(text=>$('direct-message').textContent=text);api.inspectView('grip');$('dim').textContent='Touche les pièces orange · Glisse sur le fond pour tourner';$('direct-shell').textContent='Voir le mécanisme';$('direct-back').textContent='Essayer l’allume-feu';};
 $('touch-mode').onclick=()=>startDirect();$('direct-reset').onclick=()=>startDirect();
 $('direct-shell').onclick=()=>{directOpen=!directOpen;api.directInside(directOpen);$('direct-shell').textContent=directOpen?'Refermer la coque':'Voir le mécanisme';};
 $('direct-back').onclick=()=>{directBack=!directBack;directOpen=false;api.directInside(false);api.directSide(directBack);$('direct-shell').textContent='Voir le mécanisme';$('direct-back').textContent=directBack?'Revenir à la fourchette':'Essayer l’allume-feu';$('direct-message').textContent=directBack?'Glisse la prise orange de l’allume-feu dans l’axe du manche.':'Pousse la surface orange striée vers le bout pour sortir la fourchette; glisse en sens inverse pour la ranger.';};
 $('direct-explain').onclick=()=>startInspection();
 $('direct-exit').onclick=()=>{stopDirect();$('normal-controls').hidden=false;$('views').hidden=false;$('inspect').hidden=false;mode(false);};
 const steps=()=>inspectionSteps[kind];
 const activeStep=()=>{let i=0;while(i+1<steps().length&&progress>=steps()[i+1].at-.00001)i++;return i;};
 const showInspection=()=>{
  const i=activeStep(),step=steps()[i];
  api.setInspection(inspectionPose(kind,progress),inside);
  ($('scrub') as HTMLInputElement).value=String(Math.round(progress*1000));$('percent').textContent=`${Math.round(progress*100)} %`;
  $('step-title').textContent=step.name;$('step-text').textContent=step.explanation;
  ($('previous') as HTMLButtonElement).disabled=progress===0;($('next') as HTMLButtonElement).disabled=progress===1;
  $('open-shell').textContent=inside?'Refermer la vue':'Voir à travers';
  ($('open-shell') as HTMLButtonElement).disabled=kind==='blade';
  $('latch-view').hidden=kind!=='fork';$('legend').hidden=kind!=='fork';$('grip-view').hidden=kind!=='fork';$('blocked-test').hidden=kind!=='fork';$('fork-opinion').hidden=kind!=='fork';
  $('view-note').textContent=inside?(kind==='fork'?'Coque ouverte pour observer la retenue arrondie.':kind==='fire'?'Coque arrière masquée pour voir le rail.':'Paroi de l’étui masquée pour voir les appuis.'):'Vue extérieure : les pièces restent en place.';
  $('dim').textContent='Inspection · tourne et zoome même à l’arrêt';
 };
 const startInspection=(selected:InspectionKind='fork')=>{
  stopDirect();clear();pause();api.resetCase();state={...neutral};api.setState(state);inspecting=true;kind=selected;progress=0;inside=false;
  selectValue('mechanism').value=kind;$('inspection').hidden=false;$('normal-controls').hidden=true;$('views').hidden=true;$('inspect').hidden=true;
  showInspection();api.inspectView(kind==='fork'?'grip':'whole');
 };
 $('inspect').onclick=()=>startInspection();$('exit-inspection').onclick=()=>{stopInspection();mode(false);};
 $('mechanism').onchange=()=>startInspection(selectValue('mechanism').value as InspectionKind);
 $('scrub').oninput=()=>{pause();progress=Number(($('scrub') as HTMLInputElement).value)/1000;showInspection();};
 $('previous').onclick=()=>{pause();progress=[...steps()].reverse().find(s=>s.at<progress-.00001)?.at??0;showInspection();};
 $('next').onclick=()=>{pause();progress=steps().find(s=>s.at>progress+.00001)?.at??1;showInspection();};
 $('play').onclick=()=>{if(playing){pause();return;}if(progress>=1)progress=0;playing=true;$('play').textContent='Ⅱ Pause';clock=performance.now();playback=setInterval(()=>{const now=performance.now();progress=Math.min(1,progress+Math.min(now-clock,100)/24000*speed);clock=now;showInspection();if(progress>=1)pause();},33);};
 $('speed').onchange=()=>{speed=Number(selectValue('speed').value);};
 $('open-shell').onclick=()=>{inside=!inside;showInspection();if(kind==='fork')api.inspectView(inside?'mechanism':'grip');};
 $('grip-view').onclick=()=>{pause();progress=0;inside=false;showInspection();api.inspectView('grip');};
 $('latch-view').onclick=()=>{inside=true;showInspection();api.inspectView('latch');};
 $('whole-view').onclick=()=>api.inspectView('whole');
 $('blocked-test').onclick=()=>{pause();progress=0;showInspection();$('step-title').textContent='Retenue sans bouton';$('step-text').textContent='Pousse la surface orange striée vers le bout : le téton arrondi s’efface. Le ressort doit être réglé pour retenir la fourchette sans rendre son retrait trop difficile.';};
 const draw=()=>{api.setState(state);$('knife').classList.toggle('selected',!state.case);$('case').classList.toggle('selected',state.case);$('knife-actions').hidden=state.case;$('case-actions').hidden=!state.case;$('fork').textContent=state.fork?'Ranger la fourchette':'Sortir la fourchette';($('fork') as HTMLButtonElement).disabled=false;$('blade').textContent=state.blade?'Fermer la lame':'Ouvrir la lame';$('fire').textContent=state.fire?'Ranger l’allume-feu':'Sortir l’allume-feu';$('inside').textContent=state.exploded?'Réassembler':'Vue éclatée';$('take').textContent=state.housed?'Sortir le couteau':'Ranger le couteau';$('push').textContent=state.gate?'Repousser au fond':'Pousser par l’avant';($('push') as HTMLButtonElement).disabled=!state.housed;$('hone').textContent=state.hone?'Replier la tige':'Déplier la tige';($('hone') as HTMLButtonElement).disabled=state.housed;$('case-blade').textContent=state.blade?'Fermer la lame':'Ouvrir la lame';($('case-blade') as HTMLButtonElement).disabled=state.housed;$('cut').textContent=state.cutaway?'Refermer l’étui':'Voir les appuis';$('demo').textContent=demo?'Arrêter la démo':'▶ Tout voir';$('loquet').hidden=state.case;$('dim').textContent=state.case?'Étui · 117 × 48,4 × 24,75 mm':'Couteau fermé · 120 × 30 × 16,1 mm';};
 const patch=(s:Partial<ModelState>,msg:string)=>{clear();state={...state,...s};labels(msg);draw();};
 const mode=(isCase:boolean)=>{stopDirect();if(inspecting)stopInspection();clear();api.resetCase();state={...neutral,case:isCase,housed:isCase,blade:!isCase};api.view('front');labels(isCase?'Les aiguiseurs sont sous l’étui. Inspecte leurs mouvements avec le bouton ci-dessus.':'Glisse sur le couteau pour le faire tourner. « Comprendre les mécanismes » permet de regarder au ralenti.');draw();};
 $('knife').onclick=()=>mode(false);$('case').onclick=()=>mode(true);
 $('blade').onclick=()=>patch({blade:!state.blade},'Ouverture manuelle · crochet protégé une fois fermé.');
 $('fork').onclick=()=>{patch({fork:!state.fork,top:false},state.fork?'La fourchette retrouve son logement.':'Pousse les stries orange vers le bout, puis saisis l’embout dégagé.');};
 $('fire').onclick=()=>{patch({fire:!state.fire},'Cartouche allume-feu amovible.');api.view('back');};
 $('inside').onclick=()=>{patch({exploded:!state.exploded},'Vue éclatée des logements.');api.view('front');};
 $('loquet').onclick=()=>{startInspection();inside=true;showInspection();api.inspectView('mechanism');};
 $('front').onclick=()=>api.view('front');$('back').onclick=()=>api.view('back');$('edge').onclick=()=>api.view('edge');$('reset').onclick=()=>mode(state.case);
 $('take').onclick=()=>patch({housed:!state.housed,gate:false,blade:false,hone:false},state.housed?'Le couteau glisse hors de l’étui.':'Les appuis guident le manche jusqu’au cran.');
 $('push').onclick=()=>patch({gate:!state.gate},'Le doigt pousse directement le couteau par l’ouverture avant.');
 $('hone').onclick=()=>patch({hone:!state.hone},'La tige se déplie vers le bas, à l’extérieur de l’étui.');
 $('case-blade').onclick=()=>patch({blade:!state.blade},'Lame du couteau retiré de l’étui.');
 $('cut').onclick=()=>patch({cutaway:!state.cutaway},'Les patins suivent le manche; ils ne sont pas retournés avec les aiguiseurs.');
 $('demo').onclick=()=>{if(demo){clear();api.setPaused(true);draw();return;}mode(false);demo=true;const frames:[number,Partial<ModelState>,string,string][]=[
 [0,{blade:true},'front','Lame satinée, crochet rentrant et petites stries pour le pouce.'],
 [2700,{blade:false},'front','La découpe du manche rend la lame plus facile à saisir.'],
 [4800,{top:true},'cap','Le téton arrondi se loge dans une cuvette, sans bouton.'],
 [6800,{fork:true,top:false},'front','La fourchette rigide sort avec sa prise orange.'],
 [10000,{fire:true},'back','L’allume-feu reste dans son propre logement.'],
 [13000,{...neutral,case:true,housed:true},'front','Étui compact : les aiguiseurs sont placés dessous.'],
 [16000,{housed:false},'front','Retrait du couteau.'],
 [19500,{hone:true},'front','La tige conique se déplie vers l’extérieur.'],
 [22500,{cutaway:true},'front','Les appuis intérieurs restent orientés selon le manche.'],
 [25500,{hone:false,cutaway:false},'front','La tige se replie contre sa retenue à ressort.'],
 [28000,{housed:true},'front','Retour du couteau dans son étui.']];
 for(const [t,s,v,msg] of frames)timers.push(setTimeout(()=>{state={...state,...s};api.view(v);labels(msg);draw();},t));timers.push(setTimeout(()=>{demo=false;draw();},31000));draw();};
 $('download').onclick=()=>void api.download();$('inspection-download').onclick=()=>void api.download();draw();
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
 const params=new URLSearchParams(location.search),entry=params.get('inspect');if(params.has('manipuler'))startDirect();else if(entry&&Object.hasOwn(inspectionSteps,entry))startInspection(entry as InspectionKind);
}catch(e){$('message').textContent='La vue 3D ne démarre pas. Ouvre ce fichier dans Chrome, Edge ou Safari avec WebGL activé.';console.error(e);}
