import * as T from 'three';

// Fine, mipmapped microrelief. The base green stays unchanged; no painted noise.
export function surfaceFinish(name,color,kind='composite'){
 const n=128,data=new Uint8Array(n*n*4);let seed=7919;
 for(let y=0;y<n;y++)for(let x=0;x<n;x++){
  seed=(1664525*seed+1013904223)>>>0;const noise=seed/4294967296;
  const weave=kind==='composite'?Math.sin(x*Math.PI/8)*Math.sin(y*Math.PI/8):0;
  const value=Math.round(128+weave*13+(noise-.5)*34),i=(y*n+x)*4;
  data[i]=data[i+1]=data[i+2]=value;data[i+3]=255;
 }
 const grain=new T.DataTexture(data,n,n,T.RGBAFormat);grain.name=name+' - microrelief';
 grain.wrapS=grain.wrapT=T.RepeatWrapping;grain.repeat.set(.125,.125);grain.magFilter=T.LinearFilter;grain.minFilter=T.LinearMipmapLinearFilter;grain.generateMipmaps=true;grain.needsUpdate=true;
 const m=new T.MeshStandardMaterial({color,roughness:kind==='composite'?.62:.76,metalness:0,bumpMap:grain,bumpScale:kind==='composite'?.08:.045});m.name=name;m.userData.physicalGrain=true;return m;
}

// Use millimetre-based UVs on both extruded profiles and box sidewalls.
export function mapGrain(geometry){
 const p=geometry.getAttribute('position'),normal=geometry.getAttribute('normal'),uv=new Float32Array(p.count*2);
 for(let i=0;i<p.count;i++){
  const nx=Math.abs(normal.getX(i)),ny=Math.abs(normal.getY(i)),nz=Math.abs(normal.getZ(i));
  if(nz>=nx&&nz>=ny){uv[i*2]=p.getX(i);uv[i*2+1]=p.getY(i);}
  else if(nx>=ny){uv[i*2]=p.getY(i);uv[i*2+1]=p.getZ(i);}
  else{uv[i*2]=p.getX(i);uv[i*2+1]=p.getZ(i);}
 }
 geometry.setAttribute('uv',new T.BufferAttribute(uv,2));return geometry;
}
