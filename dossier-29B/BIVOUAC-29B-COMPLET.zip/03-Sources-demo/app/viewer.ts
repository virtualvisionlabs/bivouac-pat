import * as T from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { makeModel, neutral, type ModelState } from './model';
import { makeSheath } from './sheath';
import {applyInspectionPose,type InspectionPose} from './inspection';
import {createManipulation,forkPoseForDrag} from './manipulation';
export function makeViewer(host:HTMLDivElement){
 const scene=new T.Scene();scene.background=new T.Color('#192626');
 const camera=new T.PerspectiveCamera(34,1,1,2400);camera.position.set(50,105,300);
 const renderer=new T.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;host.appendChild(renderer.domElement);
 const studio=new RoomEnvironment(),pmrem=new T.PMREMGenerator(renderer),reflection=pmrem.fromScene(studio,.04);scene.environment=reflection.texture;scene.environmentIntensity=.6;studio.dispose();pmrem.dispose();
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minDistance=100;controls.maxDistance=1600;controls.enablePan=true;
 scene.add(new T.HemisphereLight(0xf2f4e7,0x324348,1.2));
 for(const [x,y,z,power,color] of [[-90,160,240,3.2,0xfff0df],[100,60,-160,1.8,0xd4e8ff],[-150,-80,40,1.2,0xffffff]]){const light=new T.DirectionalLight(color,power);light.position.set(x,y,z);scene.add(light);}
 const model=makeModel(),sheath=makeSheath();const kit=new T.Group();kit.add(model.root,sheath.root);scene.add(kit);sheath.root.visible=false;
 let panMode=false,manualCamera=false;
 let direct:ReturnType<typeof createManipulation>|null=null,directMessage:(message:string)=>void=()=>{},directPress=0,directRear=false;
 let inspection:InspectionPose|null=null,inspectionInside=false,inspectionDirty=false,inspectionFocus='whole',motionPaused=false;
 const latchMaterial=model.latchTooth.material,highlightMaterial=new T.MeshStandardMaterial({color:0xffc76e,metalness:.35,roughness:.35});
 // Keep every annotation in a separate strip, never over the model.
 const markerStrip=document.createElement('div');
 Object.assign(markerStrip.style,{position:'absolute',bottom:'0',left:'0',right:'0',height:'34px',display:'flex',alignItems:'center',justifyContent:'center',gap:'6px',pointerEvents:'none'});
 markerStrip.hidden=true;host.appendChild(markerStrip);
 const markerElements=['1 · Bouton','2 · Prise','3 · Retenue'].map((label,i)=>{
  const el=document.createElement('span');el.className='part-marker';el.textContent=label;el.setAttribute('aria-hidden','true');
  Object.assign(el.style,{position:'static',transform:'none',width:'auto',padding:'0 9px',borderRadius:'12px',whiteSpace:'nowrap',fontSize:'11px',background:i===0?'#f5a369':i===1?'#9dd9c1':'#eef4e9'});
  markerStrip.appendChild(el);return el;
 });
 function inspectionVisibility(){
  const open=!!inspection&&inspectionInside&&inspection.kind==='fork';
  model.cover.visible=inspection?!open:!detail&&!anchorDetail&&!capDetail;
  const rim=model.front.getObjectByName('Contour évidé avant');if(rim)rim.visible=inspection?!open:!anchorDetail&&!capDetail;
  model.clip.visible=!open||!!direct;model.clipAnchors.visible=!open||!!direct;model.latchTooth.material=open?highlightMaterial:latchMaterial;for(const p of model.front.children)if(p.name==='Lèvre intégrée de guidage')p.visible=!open;
  model.fireCover.visible=!(inspection?.kind==='fire'&&inspectionInside);
  markerStrip.hidden=true;markerElements[2].hidden=!inspectionInside;
 }
 let caseTravel=0,rodProgress=0,pop=0;
 let sound:AudioContext|null=null,soundOn=false,lastSeated=true;
 function click(strong=false){if(!soundOn||!sound)return;const o=sound.createOscillator(),g=sound.createGain(),t=sound.currentTime;o.type="triangle";o.frequency.setValueAtTime(strong?430:750,t);o.frequency.exponentialRampToValueAtTime(90,t+.045);g.gain.setValueAtTime(strong?.1:.045,t);g.gain.exponentialRampToValueAtTime(.001,t+.065);o.connect(g);g.connect(sound.destination);o.start(t);o.stop(t+.07);}
 let forkProgress=0,forkExplode=0,seatPreview=0,lastFrame=performance.now();
 let state={...neutral},id=0,disposed=false,autoFit=true,detail=false,anchorDetail=false,capDetail=false,bladeDetail=false,viewDirection=new T.Vector3(.18,.16,1).normalize();
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const box=new T.Box3(),center=new T.Vector3(),size=new T.Vector3();
 function fit(){if(inspection?.kind==='fork'&&inspectionFocus==='latch'){box.min.set(29,-16,2);box.max.set(41,-1,10);}else if(inspection?.kind==='fork'&&inspectionFocus!=='whole'){box.min.set(25,-20,-3);box.max.set(77,18,22);box.expandByObject(model.tailCap);if(inspection.fork>.6)box.expandByObject(model.fork);if(direct&&direct.state.fire>0)box.expandByObject(model.fire);}else if(inspection?.kind==='case'||inspection?.kind==='hone'||!inspection&&state.case){box.setFromObject(sheath.root);box.expandByObject(model.root);}else if(bladeDetail){box.setFromObject(model.blade);}else if(capDetail){box.setFromObject(model.rocker);box.expandByObject(model.forkReceiver);for(const p of [...model.snapButtons,...model.catchReceivers])box.expandByObject(p);}else if(anchorDetail){box.setFromObject(model.clip);box.expandByObject(model.clipAnchors);}else if(detail){box.makeEmpty();for(const tooth of model.teeth)box.expandByObject(tooth);box.expandByObject(model.sockets);}else box.setFromObject(model.root);box.getCenter(center);box.getSize(size);const tanV=Math.tan(T.MathUtils.degToRad(17)),tanH=tanV*camera.aspect;const right=new T.Vector3().crossVectors(camera.up,viewDirection).normalize(),up=new T.Vector3().crossVectors(viewDirection,right).normalize();let distance=0;for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const q=new T.Vector3(x,y,z).sub(center);distance=Math.max(distance,q.dot(viewDirection)+Math.abs(q.dot(right))/tanH,q.dot(viewDirection)+Math.abs(q.dot(up))/tanV);}distance=Math.max(controls.minDistance,distance*1.16);controls.target.lerp(center,.12);camera.position.lerp(center.clone().addScaledVector(viewDirection,distance),.09);}
 function resize(){const w=Math.max(1,host.clientWidth),h=Math.max(1,host.clientHeight);renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();autoFit=true;}
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 function step(){
  if(disposed)return;id=requestAnimationFrame(step);const now=performance.now(),dt=Math.min((now-lastFrame)/1000,.05);lastFrame=now;
  if(direct){
   const desired=direct.state.pressed?1:0;
   const next=directPress+Math.sign(desired-directPress)*Math.min(Math.abs(desired-directPress),dt*5);
   if(next!==directPress){directPress=next;inspectionDirty=true;}
   if(inspectionDirty){inspection={kind:directRear?'fire':'fork',progress:0,fork:forkPoseForDrag(direct.state.fork),fire:direct.state.fire,press:directPress,automatic:!direct.state.pressed&&direct.state.fork>0,blade:0,travel:0,pop:0,hone:0};applyInspectionPose(model,sheath,inspection,inspectionInside);inspectionVisibility();inspectionDirty=false;}
  }
  else if(inspection){if(inspectionDirty){applyInspectionPose(model,sheath,inspection,inspectionInside);inspectionVisibility();inspectionDirty=false;}}
  else if(!motionPaused){
  if(reduced){model.apply(state);caseTravel=state.housed?0:1;rodProgress=state.hone?1:0;pop=state.housed&&state.gate?12:0;}else{
   const a=.13,lerp=T.MathUtils.lerp;
   model.blade.rotation.z=lerp(model.blade.rotation.z,state.blade&&(!state.case||caseTravel>.999)?-Math.PI:0,a);
   const advance=(v:number,t:number,speed:number)=>v+Math.sign(t-v)*Math.min(Math.abs(t-v),dt*speed);
   pop=advance(pop,state.housed&&state.gate?12:0,18);
   if(state.case&&Math.abs(model.blade.rotation.z)<.01){caseTravel=advance(caseTravel,state.housed?0:1,.42);}
   rodProgress=advance(rodProgress,state.hone?1:0,1.2);
   // Lift the head first, slide out, then move aside. Reverse to seat downward.
   if(state.fork||state.exploded)seatPreview=0;
   const target=seatPreview>0?(seatPreview>1.6?(capDetail?.32:.28):0):state.fork?1:0;
   seatPreview=Math.max(0,seatPreview-dt);
   forkProgress=forkProgress+Math.sign(target-forkProgress)*Math.min(Math.abs(target-forkProgress),dt*(seatPreview>0?.23:.55));
   forkExplode=lerp(forkExplode,state.exploded?42:0,a);
   model.setForkPose(forkProgress,forkExplode);
   if(forkProgress===0&&seatPreview===0)model.setSnapRelease(state.top?1:0);
   const fireY=state.fire&&model.fire.position.x>111?35:0;
   model.fire.position.y=lerp(model.fire.position.y,fireY,a);
   model.fire.position.x=lerp(model.fire.position.x,state.fire?113:Math.abs(model.fire.position.y)<.15?0:model.fire.position.x,a);
   model.fire.position.z=lerp(model.fire.position.z,state.exploded?-40:0,a);
   model.cover.position.z=lerp(model.cover.position.z,6.6+(state.exploded?20:0),a);model.front.position.z=lerp(model.front.position.z,state.exploded?23:0,a);model.back.position.z=lerp(model.back.position.z,state.exploded?-23:0,a);
   model.updateDetents();
  }
  sheath.root.visible=state.case;
  model.root.position.set(state.case?190*Math.min(caseTravel/.7,1)+pop:0,state.case?-65*Math.max((caseTravel-.7)/.3,0):0,0);
  sheath.pose(model.root.position.x,rodProgress,state.cutaway);
  const seated=model.root.position.x<.01;if(state.case&&seated&&!lastSeated)click(true);lastSeated=seated;
  }
  if(autoFit)fit();controls.update();renderer.render(scene,camera);
 }

 type TouchPart='fork'|'fire';
 let gesture:{id:number;part:TouchPart;x:number;y:number;start:number;axis:T.Vector2;length:number}|null=null;
 const picker=new T.Raycaster();
 const visibleObject=(o:T.Object3D)=>{for(let p:T.Object3D|null=o;p;p=p.parent)if(!p.visible)return false;return true;};
 const inPart=(o:T.Object3D,parent:T.Object3D)=>{for(let p:T.Object3D|null=o;p;p=p.parent)if(p===parent)return true;return false;};
 function screenPoint(p:T.Vector3){const r=renderer.domElement.getBoundingClientRect(),q=p.clone().project(camera);return new T.Vector2(r.left+(q.x+1)*r.width/2,r.top+(1-q.y)*r.height/2);}
 function castAt(x:number,y:number){const r=renderer.domElement.getBoundingClientRect();picker.setFromCamera(new T.Vector2((x-r.left)/r.width*2-1,1-(y-r.top)/r.height*2),camera);model.root.updateMatrixWorld(true);return picker.intersectObject(model.root,true).find(h=>visibleObject(h.object))?.object;}
 function classify(o:T.Object3D|undefined):TouchPart|null{if(!o)return null;if(inPart(o,model.fork))return 'fork';if(inPart(o,model.fire))return 'fire';return null;}
 function pickPart(x:number,y:number){
  const exact=classify(castAt(x,y));if(exact)return exact;
  // Touch padding is screen-only and is limited to a target visible from this camera.
  const candidates:[TouchPart,T.Vector3][]=[['fork',model.fork.localToWorld(new T.Vector3(54,0,3.58))],['fire',model.fire.localToWorld(new T.Vector3(51,0,-7.16))]];
  let chosen:TouchPart|null=null,best=24;
  for(const [part,p] of candidates){const q=screenPoint(p),distance=q.distanceTo(new T.Vector2(x,y));if(distance<best&&classify(castAt(q.x,q.y))===part){chosen=part;best=distance;}}
  return chosen;
 }
 function endGesture(){const previous=gesture;gesture=null;controls.enabled=true;if(previous&&!manualCamera)autoFit=true;if(previous&&renderer.domElement.hasPointerCapture(previous.id))renderer.domElement.releasePointerCapture(previous.id);}
 function onDirectDown(e:PointerEvent){
  if(!direct||panMode)return;if(gesture){e.stopImmediatePropagation();e.preventDefault();return;}
  const part=pickPart(e.clientX,e.clientY);if(!part)return;
  e.preventDefault();e.stopImmediatePropagation();autoFit=false;controls.enabled=false;
  const origin=screenPoint(model.root.localToWorld(new T.Vector3())),end=screenPoint(model.root.localToWorld(new T.Vector3(121,0,0))),axis=end.sub(origin),length=Math.max(70,axis.length());axis.normalize();
  gesture={id:e.pointerId,part,x:e.clientX,y:e.clientY,start:part==='fork'?direct.state.fork:direct.state.fire,axis,length};renderer.domElement.setPointerCapture(e.pointerId);
  directMessage('Appuie sur la surface orange striée et glisse vers le bout du manche.');
 }
 function onDirectMove(e:PointerEvent){
  if(!direct||!gesture||gesture.id!==e.pointerId)return;
  e.preventDefault();e.stopImmediatePropagation();
  const delta=new T.Vector2(e.clientX-gesture.x,e.clientY-gesture.y).dot(gesture.axis)/gesture.length;
  directMessage(gesture.part==='fork'?direct.moveFork(gesture.start+delta):direct.moveFire(gesture.start+delta));inspectionDirty=true;
 }
 function onDirectUp(e:PointerEvent){if(gesture?.id!==e.pointerId)return;e.stopImmediatePropagation();endGesture();}
 renderer.domElement.addEventListener('pointerdown',onDirectDown,true);
 renderer.domElement.addEventListener('pointermove',onDirectMove,true);
 renderer.domElement.addEventListener('pointerup',onDirectUp,true);
 renderer.domElement.addEventListener('pointercancel',onDirectUp,true);
 renderer.domElement.addEventListener('lostpointercapture',onDirectUp,true);
 controls.addEventListener('start',()=>{autoFit=false;manualCamera=true;});step();
 return {
 setPanMode(enabled:boolean){endGesture();panMode=enabled;controls.touches.ONE=enabled?T.TOUCH.PAN:T.TOUCH.ROTATE;controls.mouseButtons.LEFT=enabled?T.MOUSE.PAN:T.MOUSE.ROTATE;renderer.domElement.style.cursor=enabled?'move':'grab';},
 panView(dx:number,dy:number){manualCamera=true;autoFit=false;const amount=camera.position.distanceTo(controls.target)*Math.tan(T.MathUtils.degToRad(camera.fov/2))*.24;const shift=new T.Vector3(dx,dy,0).applyQuaternion(camera.quaternion).multiplyScalar(amount);camera.position.add(shift);controls.target.add(shift);controls.update();},
 recenter(){manualCamera=false;autoFit=true;},
 enableDirect(message:(text:string)=>void){endGesture();direct=createManipulation();directMessage=message;directPress=0;directRear=false;inspectionInside=false;inspectionDirty=true;inspection={kind:'fork',progress:0,fork:0,fire:0,press:0,automatic:false,blade:0,travel:0,pop:0,hone:0};inspectionVisibility();resize();message('Pose le pouce sur les stries orange dans l’ouverture de la clip, puis pousse vers le bout du manche.');},
 disableDirect(){endGesture();direct=null;inspection=null;inspectionVisibility();resize();},
 directSide(back:boolean){directRear=back;inspectionInside=false;inspectionDirty=true;viewDirection=new T.Vector3(.18,.16,back?-1:1).normalize();autoFit=true;},
 directInside(open:boolean){inspectionInside=open;inspectionDirty=true;inspectionVisibility();},
 setPaused(paused:boolean){motionPaused=paused;},
 setInspection(pose:InspectionPose|null,inside=false){if(direct){endGesture();direct=null;}const previousKind=inspection?.kind;inspection=pose?{...pose}:null;inspectionInside=inside;inspectionDirty=true;if(!pose){model.apply(state);model.root.position.set(0,0,0);}inspectionVisibility();if(previousKind!==inspection?.kind)resize();},
 inspectView(focus:string){manualCamera=false;inspectionFocus=focus;bladeDetail=detail=anchorDetail=capDetail=false;controls.minDistance=focus==='latch'?22:40;viewDirection=focus==='latch'?new T.Vector3(.8,-.65,1).normalize():focus==='grip'?new T.Vector3(.8,-.25,1).normalize():focus==='mechanism'?new T.Vector3(.1,-.5,1).normalize():new T.Vector3(.18,.16,inspection?.kind==='fire'?-1:1).normalize();autoFit=true;},
 resetCase(){caseTravel=0;rodProgress=0;pop=0;forkProgress=0;forkExplode=0;seatPreview=0;model.apply(neutral);},toggleSound(){soundOn=!soundOn;if(soundOn){sound??=new AudioContext();void sound.resume();click();}return soundOn;},setState(s:ModelState){if(s.case!==state.case){caseTravel=s.housed?0:1;rodProgress=0;pop=0;forkProgress=0;forkExplode=0;seatPreview=0;model.apply(neutral);}if(s.top!==state.top||s.bottom!==state.bottom){if(seatPreview>0){forkProgress=0;model.setForkPose(0);}seatPreview=0;}state={...s};autoFit=true;},view(side:string){manualCamera=false;bladeDetail=side==='blade';detail=side==='tips';anchorDetail=side==='clip';capDetail=side==='cap';seatPreview=detail?3.4:0;if(detail||capDetail){forkProgress=0;forkExplode=0;model.apply(neutral);}model.cover.visible=!detail&&!anchorDetail&&!capDetail;const rim=model.front.getObjectByName('Contour évidé avant');if(rim)rim.visible=!anchorDetail&&!capDetail;controls.minDistance=bladeDetail?55:detail||anchorDetail||capDetail?40:100;viewDirection=bladeDetail?new T.Vector3(0,0,1):capDetail?new T.Vector3(.15,-.4,1).normalize():anchorDetail?new T.Vector3(.15,-.8,1).normalize():detail?new T.Vector3(.25,.55,1).normalize():side==='nose'?new T.Vector3(-1,.1,.25).normalize():side==='edge'?new T.Vector3(.05,1,.08).normalize():new T.Vector3(.18,.16,side==='back'?-1:1).normalize();autoFit=true;},async download(){const m=makeModel(),assembly=new T.Group();m.apply(state);assembly.add(m.root);if(inspection){const sh=makeSheath();applyInspectionPose(m,sh,inspection,inspectionInside);if(sh.root.visible)assembly.add(sh.root);}else if(state.case){const sh=makeSheath();sh.pose(state.housed?(state.gate?12:0):190,state.hone?1:0,state.cutaway);if(state.housed&&state.gate)m.root.position.x=12;assembly.add(sh.root);if(!state.housed)m.root.position.set(190,-65,0);}assembly.scale.setScalar(.001);assembly.name='BIVOUAC_29_metres';const data=await new GLTFExporter().parseAsync(assembly,{binary:true});const url=URL.createObjectURL(new Blob([data as ArrayBuffer],{type:'model/gltf-binary'}));const a=document.createElement('a');a.href=url;a.download='BIVOUAC-29-rando.glb';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);assembly.traverse(o=>{if(o instanceof T.Mesh)o.geometry.dispose();});},dispose(){disposed=true;void sound?.close();cancelAnimationFrame(id);observer.disconnect();controls.dispose();const materials=new Set<T.Material>();scene.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m));}});const textures=new Set<T.Texture>();materials.forEach(m=>{if(m instanceof T.MeshStandardMaterial&&m.bumpMap)textures.add(m.bumpMap);m.dispose();});textures.forEach(t=>t.dispose());reflection.dispose();renderer.dispose();highlightMaterial.dispose();endGesture();renderer.domElement.removeEventListener('pointerdown',onDirectDown,true);renderer.domElement.removeEventListener('pointermove',onDirectMove,true);renderer.domElement.removeEventListener('pointerup',onDirectUp,true);renderer.domElement.removeEventListener('pointercancel',onDirectUp,true);renderer.domElement.removeEventListener('lostpointercapture',onDirectUp,true);renderer.domElement.remove();markerStrip.remove();}};
}

