// Nominal millimetres. No pull-force, fatigue or tolerance simulation.
export const clipStations=[[-5,8],[0,7.3],[4,7.2],[10,8],[44,8.1],[55,8.1]];
export function clipBottom(x){for(let i=1;i<clipStations.length;i++){const [a,z]=clipStations[i-1],[b,w]=clipStations[i];if(x<=b)return z+(w-z)*(x-a)/(b-a);}return 8.1;}
export const clipWindow={x:3.5,left:2.1,right:4.9,halfWidth:1.5};
export function detentLift(offset){let lift=0;for(let i=0;i<=120;i++){const dx=-1.5+3*i/120,x=3.5+dx-offset;if(x< -5||x>55||(x>2.1&&x<4.9))continue;const nose=8.8-Math.sqrt(Math.max(0,2.25-dx*dx));lift=Math.max(lift,clipBottom(x)+.65+.015-nose);}return lift;}
