// Direct pull-through detent illustration; no software unlock and no force simulation.
export function forkPoseForDrag(value:number){
 const t=Math.max(0,Math.min(1,value));
 if(t===0)return 0;
 if(t===1)return 1;
 if(t<.04)return .1+.1125*t/.04;
 if(t>.94)return .6625+.3375*(t-.94)/.06;
 // Invert the existing slide easing so the main translation follows the finger.
 const target=(t-.04)/.9;let a=0,b=1;
 for(let i=0;i<16;i++){const m=(a+b)/2;if(m*m*(3-2*m)<target)a=m;else b=m;}
 return .2125+.45*(a+b)/2;
}
export function createManipulation(){
 const state={fork:0,fire:0,pressed:false,returning:false};
 const clamp=(x:number)=>Math.max(0,Math.min(1,x));
 return {state,
  moveFork(value:number){const next=clamp(value);state.returning=next<state.fork;state.fork=next;
   return next===0?'Fourchette au fond : le téton retrouve sa cuvette.':next>=.999?'Fourchette sortie. Glisse-la en sens inverse pour la ranger.':state.returning?'Repousse la prise orange jusqu’au fond.':'La retenue s’efface au passage. La fourchette suit ton doigt.';
  },
  moveFire(value:number){state.fire=clamp(value);return state.fire===0?'Allume-feu rangé dans sa retenue.':state.fire>=.999?'Allume-feu sorti. La retenue agit sur le support, pas sur la pierre.':'La cartouche suit ton doigt.';}
 };
}
