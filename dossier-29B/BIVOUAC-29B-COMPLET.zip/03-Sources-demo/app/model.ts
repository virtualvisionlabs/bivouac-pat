import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {surfaceFinish,mapGrain} from './finish.mjs';
import {cutProfile,engrave} from './geometry-tools.mjs';
import {clipBottom} from './retention.mjs';
export type ModelState={fork:boolean;fire:boolean;top:boolean;bottom:boolean;blade:boolean;exploded:boolean;case:boolean;housed:boolean;gate:boolean;hone:boolean;cutaway:boolean};
export const neutral:ModelState={fork:false,fire:false,top:false,bottom:false,blade:false,exploded:false,case:false,housed:false,gate:false,hone:false,cutaway:false};
export const canReleaseFork=(top:boolean,bottom:boolean)=>true;
export function makeModel(){
 const root=new T.Group();root.name='BIVOUAC_29_mm';
 const wood=surfaceFinish('G10 vert forêt et noir',0x293d35);
 const steel=new T.MeshStandardMaterial({color:0xc4ced0,metalness:.8,roughness:.29});steel.name='Inox 316L poli';const bladeSteel=steel.clone();bladeSteel.name='Alleima 14C28N satiné';bladeSteel.roughness=.4;const springSteel=steel.clone();springSteel.name='Inox ressort 301';const acetal=new T.MeshStandardMaterial({color:0xd8d7c6,roughness:.65});acetal.name='POM-C naturel - grade contact alimentaire à certifier';
 const dark=new T.MeshStandardMaterial({color:0x273333,metalness:.28,roughness:.62});
 const orange=new T.MeshStandardMaterial({color:0xe68e53,roughness:.65});
 const ferro=new T.MeshStandardMaterial({color:0x767a78,metalness:.3,roughness:.92});
 function group(name:string,parent:T.Object3D=root){const g=new T.Group();g.name=name;parent.add(g);return g;}
 function mesh(g:T.BufferGeometry,m:T.Material,p:T.Object3D,n:string,x=0,y=0,z=0){if(m.userData.physicalGrain)mapGrain(g);const o=new T.Mesh(g,m);o.name=n;o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;p.add(o);return o;}
 function box(p:T.Object3D,n:string,x:number,y:number,z:number,w:number,h:number,d:number,m:T.Material=dark){return mesh(new T.BoxGeometry(w,h,d),m,p,n,x,y,z);}
 function profile(p:T.Object3D,n:string,pts:number[][],z:number,d:number,m:T.Material,bevel=0,bores:number[][]=[]){const s=new T.Shape();pts.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();for(const [x,y,r] of bores){const h=new T.Path();h.absarc(x,y,r,0,Math.PI*2,true);s.holes.push(h);}const cuts:number[][]=[];if(n==='Contour évidé arrière')cuts.push([33,51,-8.6,-5.7]);if(n==='Coque continue vert forêt')cuts.push([43.7,61,-5.2,5.2]);return mesh(cuts.length?cutProfile(s,cuts,d):new T.ExtrudeGeometry(s,{depth:d,steps:1,bevelEnabled:bevel>0,bevelSize:bevel,bevelThickness:bevel,bevelSegments:2}),m,p,n,0,0,z);}
 function pin(p:T.Object3D,n:string,x:number,y:number,z:number,r:number,d:number,m:T.Material=steel){const o=mesh(new T.CylinderGeometry(r,r,d,32),m,p,n,x,y,z);o.rotation.x=Math.PI/2;return o;}
 // A broad sloping underside, with no concave finger scallop.
 // Coins arrondis (rayon ~2-3mm) pour un look plus organique, moins "carré".
 // Rainures ergonomiques (x=5..41) et zone pointe de lame conservées intactes.
 const outline=[[-59.95,-2.53],[-60.00,-4.96],[-59.40,-7.32],[-58.74,-8.14],[-57.77,-9.81],[-56.34,-11.11],[-54.08,-12.61],[-51.90,-13.62],[-49.50,-13.88],[-42,-13.5],[-37,-10.5],[-33,-9.2],[-13,-9.2],[-6,-12.9],[0,-14],[5,-14.5],[8,-14.0],[11,-13.8],[14,-14.0],[17,-14.5],[20,-14.0],[23,-13.8],[26,-14.0],[29,-14.5],[32,-14.0],[35,-13.8],[38,-14.0],[41,-14.5],[41.55,-14.64],[43.01,-15.00],[44.48,-14.73],[52.52,-13.27],[53.97,-12.90],[55.34,-12.33],[57.76,-11.12],[59.44,-9.66],[60,-7.5],[60,7.5],[59.44,9.66],[57.76,11.12],[55.34,12.33],[53.96,12.88],[52.51,13.18],[38.49,14.82],[37.0,14.96],[35.5,15],[-40,15],[-41.98,14.86],[-43.92,14.43],[-50.08,12.57],[-51.94,11.87],[-53.66,10.89],[-56.34,9.11],[-57.66,7.78],[-58.30,6.02]];
 const liners=group('Platines séparant les accessoires de la lame');
 profile(liners,'Platine avant',outline,1.25,.65,steel,0,[[-50,0,2.5]]);profile(liners,'Platine arrière',outline,-1.9,.65,steel,0,[[-50,0,2.5]]);
 // Central cavity remains empty: no solid block through the blade.
 box(liners,'Entretoise du talon',55,0,0,5,17,2.5);
 pin(liners,'Axe de lame indicatif',-50,0,0,2.5,3.8);
 const blade=group('Lame sur pivot - verrouillage non conçu');blade.position.x=-50;
 // Contour redrawn from Patrick's red outline: straight heel, sweeping belly,
 // and a rearward-facing lip cut into the fore-spine, below its overall envelope.
 const bladeShape=new T.Shape();bladeShape.moveTo(-5,-4);bladeShape.lineTo(0,-6);
 bladeShape.quadraticCurveTo(6,-11,12,-13);for(let i=0;i<8;i++){const x=12.3+i*1.1;bladeShape.lineTo(x,-13);bladeShape.lineTo(x+.32,-12.55);bladeShape.lineTo(x+.64,-13);}bladeShape.lineTo(38,-13);
 bladeShape.bezierCurveTo(46,-13,49,-13.6,52,-12.7);
 bladeShape.bezierCurveTo(60,-10,69,-6.7,76.1,-4.5);
 // Enter the throat first, curl back toward the handle, then continue to the nose.
 bladeShape.bezierCurveTo(78.7,-3.7,79.5,-6.2,78.5,-8.6);
 bladeShape.quadraticCurveTo(77.1,-11.8,73,-13.68);
 bladeShape.bezierCurveTo(79,-12.1,89,-8.2,94,-4.42);
 bladeShape.bezierCurveTo(91,-.4,85,4.5,80.15,6.07);
 bladeShape.bezierCurveTo(76,8.1,70,9.2,65.67,9.2);
 bladeShape.bezierCurveTo(51,9.4,33,7.3,22.27,6.5);
 bladeShape.lineTo(16,6);bladeShape.lineTo(12,6);bladeShape.lineTo(8,7);bladeShape.lineTo(-4,6);bladeShape.lineTo(-6,1);bladeShape.closePath();
 const pivotBore=new T.Path();pivotBore.absarc(0,0,2.55,0,Math.PI*2,true);bladeShape.holes.push(pivotBore);
 bladeSteel.color.setHex(0xb8c2c5);bladeSteel.metalness=.95;bladeSteel.roughness=.3;
 mesh(new T.ExtrudeGeometry(bladeShape,{depth:2,bevelEnabled:false,curveSegments:40}),bladeSteel,blade,'Lame drop-point à facettes',0,0,-1);
 // A long, curved satin grind follows the cutting edge instead of a triangular decal.
 const grind=new T.Shape();grind.moveTo(22.27,-3.2);grind.bezierCurveTo(38,-2.8,56,-.9,67,.2);
 grind.bezierCurveTo(81,1.6,89,-2,94,-4.42);
 grind.bezierCurveTo(91,-.4,85,4.5,80.15,6.07);grind.bezierCurveTo(76,8.1,70,9.2,65.67,9.2);
 grind.bezierCurveTo(51,9.4,33,7.3,22.27,6.5);grind.closePath();
 const grindMat=new T.MeshStandardMaterial({color:0x8b9ba3,metalness:1,roughness:.2,side:T.DoubleSide});
 for(const sign of [-1,1]){
  const g=new T.ShapeGeometry(grind,40);const pos=g.getAttribute('position');
  // Subtle curvature produces a continuous reflection across the bevel surface.
  for(let i=0;i<pos.count;i++)pos.setZ(i,sign*(1.012+.018*Math.sin((pos.getY(i)+4)/14*Math.PI)));
  g.computeVertexNormals();mesh(g,grindMat,blade,'Émouture satinée continue');
 }
 const nick=new T.Shape();nick.moveTo(24,-12.4);nick.quadraticCurveTo(31,-10.8,40,-11.8);nick.quadraticCurveTo(32,-12,24,-12.4);
 const etched=new T.MeshStandardMaterial({color:0x354447,metalness:.55,roughness:.68,side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
 for(const sign of [-1,1])mesh(new T.ShapeGeometry(nick),etched,blade,'Prise à ongle — empreinte proposée',0,0,sign*1.005);
 // Small vector marking, readable with the blade opened. Visual laser-etch proposal.
 const letters:Record<string,number[][][]>={B:[[[0,0],[0,2],[.9,2],[1.2,1.7],[1.2,1.3],[.9,1],[0,1]],[[.9,1],[1.2,.7],[1.2,.3],[.9,0],[0,0]]],I:[[[.6,0],[.6,2]]],V:[[[0,2],[.6,0],[1.2,2]]],O:[[[.2,0],[0,.3],[0,1.7],[.2,2],[1,2],[1.2,1.7],[1.2,.3],[1,0],[.2,0]]],U:[[[0,2],[0,.3],[.3,0],[.9,0],[1.2,.3],[1.2,2]]],A:[[[0,0],[.6,2],[1.2,0]],[[.25,.8],[.95,.8]]],C:[[[1.2,1.8],[.9,2],[.3,2],[0,1.7],[0,.3],[.3,0],[.9,0],[1.2,.2]]]};
 const mark=group('Marquage BIVOUAC discret',blade);mark.position.set(40,-6,1.04);mark.rotation.z=Math.PI;
 [...'BIVOUAC'].forEach((letter,k)=>letters[letter].forEach(path=>{for(let i=1;i<path.length;i++){const [x1,y1]=path[i-1],[x2,y2]=path[i],dx=x2-x1,dy=y2-y1;const stroke=box(mark,'Trait gravure BIVOUAC',k*1.8+(x1+x2)/2,(y1+y2)/2,0,Math.hypot(dx,dy),.11,.003,etched);stroke.rotation.z=Math.atan2(dy,dx);}}));
 const scrapeGeometry=new T.BufferGeometry();scrapeGeometry.setAttribute('position',new T.Float32BufferAttribute([22,-13.005,-1,38,-13.005,-1,38,-13.005,1,22,-13.005,1],3));scrapeGeometry.setIndex([0,1,2,0,2,3]);scrapeGeometry.computeVertexNormals();
 mesh(scrapeGeometry,new T.MeshStandardMaterial({color:0xd6dcd6,metalness:.8,roughness:.48,side:T.DoubleSide}),blade,'Zone droite de grattage, sans encoche');
 const front=group('Plaquette avant avec poche intégrée');
 const back=group('Plaquette arrière avec poche intégrée');
 profile(front,'Fond de poche avant',outline,1.9,.2,wood);
 profile(back,'Fond de poche arrière',outline,-2.7,.8,wood);
 const mouthIndex=outline.findIndex(([x,y])=>x===60&&y>0);
 const frontRim=[...outline.slice(mouthIndex),...outline.slice(0,mouthIndex),[60,-8.5],[-46,-8.5],[-48,-6],[-48,6],[-46,8.5],[60,8.5]];
 const rim=group('Contour évidé avant',front);
 profile(rim,'Bord inférieur continu',frontRim,2.1,.5,wood);
 profile(rim,'Bord supérieur continu',frontRim,5.9,1.3,wood);
 // Broad side approaches expose the thumb pads directly, without deep finger holes.
 const fingerRelief=profile(rim,'Approches ouvertes pour pouce et index',frontRim,2.6,3.3,wood);
 const backRim=[...outline.slice(mouthIndex),...outline.slice(0,mouthIndex),[60,-6],[-41,-6],[-43,-4],[-43,4],[-41,6],[60,6]];
 profile(back,'Contour évidé arrière',backRim,-7.2,4.5,wood);
 // Opaque outer skin closes the rod channel; only the orange pull remains visible.
 const fireCover=profile(back,'Coque pleine de l’allume-feu',[...outline.slice(mouthIndex),...outline.slice(0,mouthIndex),[60,-6],[35.8,-6],[35.8,6],[60,6]],-7.2,.5,wood);
 profile(front,'Insert de logement POM-C',[[60,-8],[-50,-8],[-50,8],[60,8]],2.1,.2,acetal);
 const catchReceivers:T.Mesh[]=[];
 for(const sign of [-1,1]){
  if(sign>0)box(front,'Guide POM-C remplaçable',4.5,7.5,4.1,93,.2,2.4,acetal);else{box(front,'Guide avant de retenue',-10,-7.5,4.1,64,.2,2.4,acetal);box(front,'Guide arrière de la bascule',45.5,-7.5,4.1,11,.2,2.4,acetal);}

 }
 // Four shallow, downward-facing pockets above the continuous food-contact floor.
 const toothGuides=group('Insert à quatre creux orientés vers le bas',front);
 const socketShape=new T.Shape();socketShape.moveTo(-49.8,-8);socketShape.lineTo(-43.5,-8);socketShape.lineTo(-43.5,8);socketShape.lineTo(-49.8,8);socketShape.closePath();
 const socketCenters=[-5.7,-1.9,1.9,5.7];const socketRadius=1.4;const socketZ=2.3;
 for(const y of socketCenters){const hole=new T.Path();hole.absellipse(-47,y,2,1.4,0,Math.PI*2,true,0);socketShape.holes.push(hole);}
 const socketGeometry=new T.ExtrudeGeometry(socketShape,{depth:.65,bevelEnabled:false,curveSegments:48});
 const socketVertices=socketGeometry.getAttribute('position');
 for(let i=0;i<socketVertices.count;i++){const h=.02+.63*T.MathUtils.clamp((-44-socketVertices.getX(i))/3,0,1);socketVertices.setZ(i,socketVertices.getZ(i)/.65*h);}
 socketGeometry.computeVertexNormals();
 const sockets=mesh(socketGeometry,acetal,toothGuides,'Quatre creux de pointe avec entrée en pente',0,0,2.3);
 // Continuous cover following the handle silhouette, not an attached rectangular housing.
 const cover=profile(front,'Coque continue vert forêt',outline,6.6,.58,wood);
 for(const y of [-8.1,8.1])box(front,'Lèvre intégrée de guidage',7,y,6.75,102,.8,.9,dark);
 // Flush decorative inserts are separate faces, with a depth bias rather than intersecting solids.
 const screwMark=dark.clone();screwMark.polygonOffset=true;screwMark.polygonOffsetFactor=-2;screwMark.polygonOffsetUnits=-2;screwMark.side=T.DoubleSide;
 const accentMaterial=orange.clone();accentMaterial.name='Insert orange affleurant';accentMaterial.side=T.DoubleSide;accentMaterial.polygonOffset=true;accentMaterial.polygonOffsetFactor=-2;accentMaterial.polygonOffsetUnits=-2;
 for(const p of [front,back]){
  const sign=p===front?1:-1;pin(p,'Vis du pivot',-50,0,sign*7.05,3.9,.3);mesh(new T.PlaneGeometry(3.2,.65),screwMark,p,'Empreinte de vis',-50,0,sign*7.2);
  const patch=new T.Shape();patch.moveTo(-34,10);patch.lineTo(-28,10);patch.lineTo(-23.2,13.35);patch.lineTo(-29.2,13.35);patch.closePath();
  mesh(new T.ShapeGeometry(patch),accentMaterial,p,'Accent orange affleurant sans superposition',0,0,sign*7.2);
 }
 const clip=group('Clip fine indépendante',front);
 // Raised mounting at the heel; two fixed shoulders leave a rear-open thumb window.
 // A small through-window receives the sheath's rounded spring detent.
 const clipShape=new T.Shape();clipShape.moveTo(-5,-4);clipShape.lineTo(38,-4);clipShape.lineTo(44,-10);clipShape.lineTo(55,-10);clipShape.lineTo(55,-6);clipShape.lineTo(45.2,-6);clipShape.quadraticCurveTo(43.7,-6,43.7,-4.5);clipShape.lineTo(43.7,4.5);clipShape.quadraticCurveTo(43.7,6,45.2,6);clipShape.lineTo(55,6);clipShape.lineTo(55,10);clipShape.lineTo(44,10);clipShape.lineTo(38,4);clipShape.lineTo(-5,4);clipShape.closePath();
 const window=new T.Path();window.moveTo(2.35,-1.5);window.lineTo(4.65,-1.5);window.quadraticCurveTo(4.9,-1.5,4.9,-1.25);window.lineTo(4.9,1.25);window.quadraticCurveTo(4.9,1.5,4.65,1.5);window.lineTo(2.35,1.5);window.quadraticCurveTo(2.1,1.5,2.1,1.25);window.lineTo(2.1,-1.25);window.quadraticCurveTo(2.1,-1.5,2.35,-1.5);window.closePath();clipShape.holes.push(window);
 // Subdivide long faces before bending so the original pocket-clip camber is retained.
 const flatClip=new T.ExtrudeGeometry(clipShape,{depth:.65,bevelEnabled:false,curveSegments:20}),cp=flatClip.getAttribute('position'),cv:number[]=[];
 function trim(poly:T.Vector3[],x:number,greater:boolean){const out:T.Vector3[]=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],ia=greater?a.x>=x:a.x<=x,ib=greater?b.x>=x:b.x<=x;if(ia)out.push(a);if(ia!==ib)out.push(a.clone().lerp(b,(x-a.x)/(b.x-a.x)));}return out;}
 const breaks=[-5,0,4,10,38,43.7,44,55];for(let n=0;n<cp.count;n+=3)for(let k=1;k<breaks.length;k++){const poly=trim(trim([0,1,2].map(i=>new T.Vector3().fromBufferAttribute(cp,n+i)),breaks[k-1],true),breaks[k],false);for(let j=1;j<poly.length-1;j++)for(const v of [poly[0],poly[j],poly[j+1]])cv.push(v.x,v.y,v.z+clipBottom(v.x));}
 const clipGeometry=new T.BufferGeometry();clipGeometry.setAttribute('position',new T.Float32BufferAttribute(cv,3));clipGeometry.computeVertexNormals();flatClip.dispose();
 const clipBlade=mesh(clipGeometry,springSteel,clip,'Languette droite centrée');
 for(const sign of [-1,1])box(clip,'Épaulement ouvert de clip',54,sign*9.35,8.5,6,6.7,.8,springSteel);
 const clipAnchors=group('Fixations de clip hors du passage',front),clipScrews:T.Mesh[]=[];
 for(const y of [-10.7,10.7]){
  const x=54;box(clip,'Pied sur bord plein',x,y,7.65,6,4,.9,steel);
  pin(clipAnchors,'Fond fermé de douille',x,y,3.85,1.7,.5,steel);
  const ring=new T.Shape();ring.absarc(x,y,1.7,0,Math.PI*2,false);const bore=new T.Path();bore.absarc(x,y,.8,0,Math.PI*2,true);ring.holes.push(bore);
  mesh(new T.ExtrudeGeometry(ring,{depth:2.5,bevelEnabled:false,curveSegments:24}),steel,clipAnchors,'Douille filetée borgne proposée',0,0,4.1);
  clipScrews.push(pin(clipAnchors,'Tige de vis de clip - filetage indicatif',x,y,6.4,.78,4.2,steel));
  pin(clip,'Tête de vis de clip',x,y,8.74,1.45,.28,steel);box(clip,'Empreinte de vis de clip',x,y,8.89,1.6,.35,.01,dark);
 }
 engrave(clip,'BIVOUAC',14,-1.4,8.76,.95);
 const fork=group('Fourchette indépendante');fork.position.z=3.5;
 // Cross-section sweep bends the neck as well as the entire head; the handle remains flat.
 const headVertices:number[]=[],headIndices:number[]=[];
 const headStations=[...Array.from({length:37},(_,i)=>-26+i*.5),0,24,48,58.5];
 for(const x of headStations){const width=x<=-17?7:x<-8?7-(x+17)*3.2/9:x<=48?3.8:3.8-(x-48)*1.8/10.5;const t=T.MathUtils.clamp((-8-x)/17,0,1),drop=-.45*t*t*(3-2*t);for(const [y,z] of [[-width,0],[width,0],[-width,1.2],[width,1.2]])headVertices.push(x,y,drop+z);}
 function sweepIndices(count:number){const idx:number[]=[];for(let i=0;i<count-1;i++){const a=i*4,b=a+4;idx.push(a,a+1,b,a+1,b+1,b,a+2,b+2,a+3,a+3,b+2,b+3,a,b,a+2,a+2,b,b+2,a+1,a+3,b+1,a+3,b+3,b+1);}idx.push(0,2,1,1,2,3);const e=(count-1)*4;idx.push(e,e+1,e+2,e+1,e+3,e+2);return idx;}
 headIndices.push(...sweepIndices(headStations.length));
 const headGeometry=new T.BufferGeometry();headGeometry.setAttribute('position',new T.Float32BufferAttribute(headVertices,3));headGeometry.setIndex(headIndices);headGeometry.computeVertexNormals();
 const forkHead=mesh(headGeometry,steel,fork,'Fourchette - col et tête galbés');
 const teeth:T.Mesh[]=[];
 for(const y of [-5.7,-1.9,1.9,5.7]){
  const tooth=profile(fork,'Dent courbée de fourchette',[[-47,y-.3],[-45,y-1],[-25,y-1],[-25,y+1],[-45,y+1],[-47,y+.3]],0,1.2,steel,.07);
  // Re-tessellate longitudinally before bending: a long flat triangle cannot represent a curve.
  fork.remove(tooth);tooth.geometry.dispose();
  const vertices:number[]=[],indices:number[]=[];const steps=32;
  for(let i=0;i<=steps;i++){const t=i/steps,x=-25-22*t,half=t>.9?1-(t-.9)*7:1,lift=-.45-.55*t**4;for(const [dy,dz] of [[-half,0],[half,0],[-half,1.2],[half,1.2]])vertices.push(x,y+dy,lift+dz);}
  for(let i=0;i<steps;i++){const a=i*4,b=a+4;indices.push(a,b,a+1,a+1,b,b+1,a+2,a+3,b+2,a+3,b+3,b+2,a,a+2,b,a+2,b+2,b,a+1,b+1,a+3,a+3,b+1,b+3);}
  indices.push(0,1,2,1,3,2);const e=steps*4;indices.push(e,e+2,e+1,e+1,e+2,e+3);
  const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geometry.setIndex(indices);geometry.computeVertexNormals();
  teeth.push(mesh(geometry,steel,fork,'Dent courbée de fourchette'));
 }
 // Rigid fork with one fixed heel enclosure; no extension, folding joint or sliding handle.
 const tailCap=group('Embout affleurant solidaire de fourchette',fork);
 const capOutline=[[56.5,-8.45],[59.65,-8.45],[60,-8.1],[60,8.1],[59.65,8.45],[56.5,8.45]];
 profile(tailCap,'Semelle profilée du talon',capOutline,-1.1,.8,wood);
 profile(tailCap,'Fermeture pleine du bout',[[59.6,-8.45],[60,-8.1],[60,8.1],[59.6,8.45]],-.3,3.38,wood);
 const forkGrip=profile(tailCap,'Prise orange de 16 mm',[[44,-5],[56.5,-5],[56.5,-8.45],[59.6,-8.45],[60,-8.1],[60,8.1],[59.6,8.45],[56.5,8.45],[56.5,5],[44,5]],1.2,1.88,orange);
 // Thumb ribs sit below the shell envelope, exposed between the fixed clip shoulders.
 for(const x of [46,49,52,55,58])mesh(new RoundedBoxGeometry(1.2,8,.5,3,.12),orange,tailCap,'Nervure de poussée fourchette',x,0,3.33);
 profile(fork,'Prise fixe de fourchette',[[2,-3.4],[43,-3.4],[43,3.4],[2,3.4]],1.2,.65,acetal);
 // Rounded spring noses seat in shallow side recesses; no button or positive lock.
 function camEdge(x:number,start:number,end:number,gx:number,edge:number){
  if(x<start||x>end)return null;
  const lead=Math.max(0,1-(x-start)/1.2)*2.2;
  const groove=Math.abs(x-gx)<1.1?Math.sqrt(1.21-(x-gx)**2):0;
  return edge+Math.max(lead,groove);
 }
 function camOutline(start:number,end:number,gx:number,edge:number,inner:number){
  const xs=[start,start+1.2,end,gx-1.1,gx+1.1];for(let i=0;i<=64;i++)xs.push(gx+1.1*Math.cos(Math.PI*i/64));
  const pts=[...new Set(xs.map(x=>Number(x.toFixed(8))))].sort((a,b)=>a-b).map(x=>[x,camEdge(x,start,end,gx,edge)!]);pts.push([end,inner],[start,inner]);return pts;
 }

 const forkReceiver=profile(fork,'Cuvette arrondie de retenue fourchette',camOutline(30,40,35,-6.2,-3.4),0,1.2,steel);catchReceivers.push(forkReceiver);
 function makeDetent(parent:T.Group,name:string,x:number,z:number,restY:number){
  const assembly=group(name,parent),radius=.65,anchorX=x-11,anchorY=-7.7;
  box(assembly,'Ancrage vissé de lame-ressort',anchorX,anchorY,z,2.5,1,1,acetal);
  pin(assembly,'Vis de retenue du ressort',anchorX,anchorY,z+.55,.55,.3,steel);
  const vertices:number[]=[],indices:number[]=[];
  for(let i=0;i<=24;i++){const t=i/24,y=anchorY+(restY-anchorY)*t*t;for(const [dy,dz] of [[-.12,-.45],[.12,-.45],[-.12,.45],[.12,.45]])vertices.push(anchorX+11*t,y+dy,z+dz);}
  indices.push(...sweepIndices(25));const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geometry.setIndex(indices);geometry.computeVertexNormals();
  const leaf=mesh(geometry,springSteel,assembly,'Lame-ressort de retenue proposée');
  const nose=mesh(new T.SphereGeometry(radius,24,16),steel,assembly,'Téton arrondi de retenue',x,restY,z);
  function follow(travel:number,side:number,start:number,end:number,gx:number,edge:number){let y=restY;
   for(let i=0;i<=80;i++){const dx=-radius+2*radius*i/80,bound=camEdge(x+dx-travel,start,end,gx,edge);if(bound!==null)y=Math.min(y,bound+side-Math.sqrt(Math.max(0,radius*radius-dx*dx))-.01);}
   nose.position.y=y;const attr=geometry.getAttribute('position');for(let i=0;i<attr.count;i++){const t=Math.floor(i/4)/24;attr.setY(i,vertices[i*3+1]+(y-restY)*t*t);}attr.needsUpdate=true;geometry.computeVertexNormals();return restY-y;
  }
  return {assembly,leaf,nose,follow,restY};
 }
 const forkDetent=makeDetent(front,'Retenue arrondie de fourchette',35,4.15,-5.76);
 // Compatibility references for saved views; these are now the internal detent, never a button.
 const rocker=forkDetent.assembly,latchTooth=forkDetent.nose,releaseButton=forkDetent.nose,latchSpring=forkDetent.leaf;
 const snapArms:T.Mesh[]=[latchSpring],snapHooks:T.Mesh[]=[latchTooth],snapButtons:T.Mesh[]=[];
 function setSnapRelease(_pressed:number,_unused=0){}
 // Proposed pressure leaf, shown flexing kinematically; no spring-force calculation.
 const leafVertices:number[]=[],leafSteps=24;
 for(let i=0;i<=leafSteps;i++){const t=i/leafSteps;for(const [y,dz] of [[-1.6,0],[1.6,0],[-1.6,.15],[1.6,.15]])leafVertices.push(-18+14*t,y,6.2-1.5*t*t+dz);}
 const leafGeometry=new T.BufferGeometry();leafGeometry.setAttribute('position',new T.Float32BufferAttribute(leafVertices,3));leafGeometry.setIndex(sweepIndices(leafSteps+1));leafGeometry.computeVertexNormals();
 const pressureLeaf=mesh(leafGeometry,springSteel,front,'Languette de pression proposée');
 box(front,'Ancrage de languette',-18,0,6.475,2,3.2,.25,springSteel);
 function setForkPose(progress:number,explodeOffset=0){
  const easing=(p:number,a:number,b:number)=>{const t=T.MathUtils.clamp((p-a)/(b-a),0,1);return t*t*(3-2*t);};

  const forkPhase=T.MathUtils.clamp((progress-.1)/.75,0,1);
  const smooth=(a:number,b:number)=>easing(forkPhase,a,b);
  const lift=smooth(0,.15)*(1-smooth(.75,1)),angle=.008*lift,slide=121*smooth(.15,.75);
  fork.rotation.y=angle;fork.position.set(slide+58.5*(1-Math.cos(angle)),-39*smooth(.75,1),3.5+58.5*Math.sin(angle)+explodeOffset);
  forkDetent.follow(fork.position.x,fork.position.y,30,40,35,-6.2);
  const positions=leafGeometry.getAttribute('position');for(let i=0;i<positions.count;i++){const t=Math.floor(i/4)/leafSteps;positions.setZ(i,leafVertices[i*3+2]+.5*lift*t*t);}positions.needsUpdate=true;leafGeometry.computeVertexNormals();
 }
 // Commercial miniature rod retains its curved face; support stays below its equator.
 const fire=group('Cartouche allume-feu bombée');
 box(fire,'Support inox 316L de cartouche',6,0,-2.95,66,5,.3,steel);
 const fireRod=mesh(new T.CylinderGeometry(1.9,1.9,50.8,40),ferro,fire,'FireSteel Miniature 3,8 x 50,8 mm',10,0,-4.7);fireRod.rotation.z=Math.PI/2;
 for(const y of [-2.1,2.1])box(fire,'Joue de support inox',10,y,-3.5,51,.3,1.1,steel);
 box(fire,'Butée de cartouche',-16,0,-4.25,1.2,5,2.6,steel);
 const fireGrip=profile(fire,'Prise de cartouche affleurante',camOutline(36,60,46,-5.85,5.85),-6.7,3.8,orange);
 for(const x of [42,45,48,51,54,57])mesh(new RoundedBoxGeometry(1.2,8,.5,3,.12),orange,fire,'Nervure de poussée allume-feu',x,0,-6.91);
 for(const y of [-5.5,5.5])box(back,'Rail de cartouche encastré',-2.1,y,-5.15,75.8,1,3.5,dark);
 const fireDetent=makeDetent(back,'Retenue du support permanent allume-feu',46,-4.65,-5.41);
 const fireLatch=fireDetent.nose;
 function updateDetents(){forkDetent.follow(fork.position.x,fork.position.y,30,40,35,-6.2);fireDetent.follow(fire.position.x,fire.position.y,36,60,46,-5.85);}
 let current:ModelState={...neutral};
 function apply(s:ModelState){current={...s};blade.rotation.z=s.blade?-Math.PI:0;setForkPose(s.fork?1:0,s.exploded?42:0);if(!s.fork)setSnapRelease(s.top?1:0);fire.position.set(s.fire?113:0,s.fire?35:0,s.exploded?-40:0);front.position.z=s.exploded?23:0;cover.position.z=6.6+(s.exploded?20:0);back.position.z=s.exploded?-23:0;updateDetents();root.updateMatrixWorld(true);}
 apply(neutral);
 return {forkDetent,fireDetent,forkGrip,fireGrip,updateDetents,root,blade,front,back,fork,fire,fireCover,fireRod,fireLatch,teeth,forkHead,pressureLeaf,clip,clipBlade,clipAnchors,clipScrews,rocker,latchTooth,releaseButton,forkReceiver,latchSpring,tailCap,fingerRelief,snapArms,snapHooks,snapButtons,catchReceivers,setSnapRelease,toothGuides,sockets,cover,setForkPose,socketCenters,socketRadius,socketZ,apply,get state(){return current;}};
}


