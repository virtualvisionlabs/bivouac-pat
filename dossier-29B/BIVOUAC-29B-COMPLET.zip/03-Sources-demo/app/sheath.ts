import * as T from 'three';
import {surfaceFinish,mapGrain} from './finish.mjs';
import {engrave} from './geometry-tools.mjs';
import {detentLift} from './retention.mjs';
// Visual design in mm. Latch/linkage and tactile rail are proposed, not force-simulated.
export const caseDimensions={length:117,width:48.4,thickness:24.75,cavityWidth:30.6,cavityDepth:16.55,wall:2,rodLength:50,rodMaxDiameter:4,rodMinDiameter:1,sharpeningHalfAngle:20};
export function makeSheath(){
 const root=new T.Group();root.name='Étui aiguiseur BIVOUAC 19';
 const shell=surfaceFinish('PA12 — coque moulée proposée',0x293d35,'nylon');
 const dark=new T.MeshStandardMaterial({color:0x111d1c,roughness:.62});
 const orange=new T.MeshStandardMaterial({color:0xef782f,roughness:.52});
 const steel=new T.MeshStandardMaterial({color:0xb3bfc2,roughness:.29,metalness:.85});
 const carbide=new T.MeshStandardMaterial({color:0x657073,roughness:.4,metalness:.75});
 const ceramic=new T.MeshStandardMaterial({color:0xf2f0e4,roughness:.45});
 const diamond=new T.MeshStandardMaterial({color:0xb2b6b0,roughness:.92,metalness:.4});
 function mesh(g:T.BufferGeometry,m:T.Material,p:T.Object3D,n:string,x=0,y=0,z=0){if(m.userData.physicalGrain)mapGrain(g);const o=new T.Mesh(g,m);o.name=n;o.position.set(x,y,z);p.add(o);return o;}
 function box(p:T.Object3D,n:string,x:number,y:number,z:number,w:number,h:number,d:number,m:T.Material=shell){return mesh(new T.BoxGeometry(w,h,d),m,p,n,x,y,z);}
 function extrude(p:T.Object3D,n:string,s:T.Shape,z:number,d:number,m:T.Material=shell,bevel=0){return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:bevel>0,bevelSize:bevel,bevelThickness:bevel,bevelSegments:3,curveSegments:32}),m,p,n,0,0,z);}
 function profile(p:T.Object3D,n:string,pts:number[][],z:number,d:number,m:T.Material=shell,bevel=0){const s=new T.Shape();pts.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();return extrude(p,n,s,z,d,m,bevel);}
 function pin(p:T.Object3D,n:string,x:number,y:number,z:number,r:number,d:number){const o=mesh(new T.CylinderGeometry(r,r,d,32),steel,p,n,x,y,z);o.rotation.x=Math.PI/2;return o;}
 // Compact envelope. The rear body ends at x=52, leaving 8 mm of the knife visible.
 const shape=new T.Shape();shape.moveTo(52,-14.3);shape.quadraticCurveTo(52,-18.3,44,-18.3);shape.lineTo(-48,-18.3);shape.bezierCurveTo(-60,-18.3,-65,-12,-65,-7);shape.lineTo(-65,7);shape.bezierCurveTo(-65,20,-59,27,-49,30.1);
 for(const x of [-43,-22]){shape.lineTo(x-4.7,30.1);shape.lineTo(x,18.6);shape.lineTo(x+4.7,30.1);}
 shape.lineTo(47,30.1);shape.quadraticCurveTo(52,30.1,52,25);shape.lineTo(52,17.3);shape.lineTo(52,-14.3);shape.closePath();
 const exterior=new T.Group();exterior.name='Coque et affûteurs sous le manche';exterior.scale.y=-1;root.add(exterior);
 const floor=extrude(exterior,'Fond compact',shape,-9.45,2);
 const topShape=shape.clone(),slot=new T.Path();slot.moveTo(-21,-2);slot.lineTo(7,-2);slot.lineTo(7,2);slot.lineTo(-21,2);slot.closePath();topShape.holes.push(slot);
 const roof=extrude(exterior,'Coque compacte et fente de ressort',topShape,9.1,2);
 const walls=new T.Group();walls.name='Guidage rapproché du manche';root.add(walls);
 for(const sign of [-1,1])box(walls,'Paroi de guidage',-.5,sign*16.3,.825,105,2,16.55);
 // The nose is open centrally: a 20 x 14 mm finger approach, not an ejector spring.
 const nosePts=[[-53,-17.3],[-60,-15],[-65,-7],[-65,7],[-60,15],[-53,17.3],[-53,15.3],[-59.9,11],[-61,5],[-61,-5],[-59.9,-11],[-53,-15.3]];
 profile(walls,'Pont inférieur du passage de doigt',nosePts,-7.45,.45);
 profile(walls,'Pont supérieur du passage de doigt',nosePts,7,2.1);
 function sideClip(poly:number[][],sign:number){const out:number[][]=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],ia=sign*a[1]>=10,ib=sign*b[1]>=10;if(ia)out.push(a);if(ia!==ib){const t=(sign*10-a[1])/(b[1]-a[1]);out.push([a[0]+t*(b[0]-a[0]),sign*10]);}}return out;}
 for(const sign of [-1,1])profile(walls,'Joue du passage de doigt',sideClip(nosePts,sign),-7,14);
 // Low ceiling closely follows the body; only the knife clip gets a higher channel.
 const ceiling=profile(root,'Doublure avec canal réservé à la clip',[[-53,-15.3],[52,-15.3],[52,-13],[37.7,-13],[37.7,-4.3],[-5.4,-4.3],[-5.4,4.3],[37.7,4.3],[37.7,13],[52,13],[52,15.3],[-53,15.3]],7.45,1.65,dark);
 const pads=new T.Group();pads.name='Patins souples remplaçables — contact nominal';root.add(pads);
 const padMat=new T.MeshStandardMaterial({color:0xcf843f,roughness:.87});padMat.name='Élastomère de calage — grade et écrasement à valider';
 for(const x of [-30,28])for(const y of [x===-30?-6.8:-10,10]){
  box(pads,'Appui inférieur',x,y,-7.325,8,4,.25,padMat);
  box(pads,'Appui supérieur',x,y,7.325,8,4,.25,padMat);
 }
 for(const x of [-30,28])box(pads,'Appui latéral supérieur',x,15.15,0,8,.3,10,padMat);
 // Follow the rounded lower handle contour. Stop at its lowest point so the
 // handle can slide out along +X without catching the rising return of the pad.
 profile(pads,'Appui latéral au nez',[[-53,-15.3],[-49.5,-15.3],[-49.5,-13.88],[-51.9,-13.62],[-53,-13.110366972477]],-5,10,padMat);
 box(pads,'Appui latéral au talon',43,-15.15,0,4,.3,10,padMat);
 box(pads,'Butée axiale sur le nez fixe du manche',-60.225,-5,-5.225,.45,1.4,4.45,padMat);
 const skin=new T.Group();skin.name='Finition extérieure démontée en coupe';exterior.add(skin);
 // Raised skin details stay outside the knife cavity, with gently bevelled edges.
 const panel=profile(skin,'Médaillon noir satiné',[[-53,-9],[-44,-15],[35,-15],[44,-9],[32,10],[-41,10],[-53,4]],11.25,.3,dark,.25);
 for(let i=0;i<6;i++)profile(skin,'Nervure de prise douce',[[i*7-40,-11],[i*7-38,-11],[i*7-28,6],[i*7-30,6]],11.8,.12,shell,.12);
 profile(skin,'Signature orange du nez',[[-61,-6],[-57,-11],[-50,-13],[-47,-13],[-54,-8],[-58,2],[-60,5]],11.25,.2,orange,.15);
 profile(skin,'Accent de bord orange',[[8,13],[38,13],[46,17],[40,17],[35,15],[8,15]],11.25,.2,orange,.15);
 for(const x of [-54,48])for(const y of [-16,16]){pin(skin,'Vis de coque',x,y,11.25,1.4,.3);box(skin,'Empreinte vis',x,y,11.42,1.6,.35,.02,dark);}
 const abrasives:T.Mesh[]=[];
 for(const [x,mat,label] of [[-43,carbide,'1 · carbure'],[-22,ceramic,'2 · céramique']] as const){
  profile(exterior,'Insert porteur encastré '+label,[[x-9,17.3],[x+9,17.3],[x+9,29.1],[x+4.3,29.1],[x,18.3],[x-4.3,29.1],[x-9,29.1]],-7.45,16.55,dark);
  for(const sign of [-1,1])abrasives.push(profile(exterior,'Abrasif '+label,[[x+sign*.12,19.1],[x+sign*3.47,28.3],[x+sign*4.27,28.3],[x+sign*.92,19.1]],-4,8,mat));
  for(let j=0;j<(x===-43?1:2);j++)box(exterior,'Repère tactile '+label,x+j*2-1,17,11.32,.8,2,.15,orange);
 }
 const rodTray=new T.Group();rodTray.name='Tige encastrée dans l’épaulement';exterior.add(rodTray);
 box(rodTray,'Fond de rainure tige',20,18.9,0,64,1.2,5.2,dark);
 const hone=new T.Group();hone.name='Tige diamantée rabattable';hone.position.set(46,23.1,0);exterior.add(hone);
 const rod=mesh(new T.CylinderGeometry(.5,2,50,24),diamond,hone,'Tige conique diamantée 50 mm',-30,0,0);rod.rotation.z=Math.PI/2;
 box(hone,'Embout de prise orange',-2.5,0,0,5,4.4,4.4,orange);
 pin(exterior,'Pivot de tige',46,23.1,0,1.7,18.9);
 // Pivot cam has a closed-position flat. The spring shoe follows its lower outline.
 const camPoints:number[][]=[];for(let i=0;i<128;i++){const a=2*Math.PI*i/128;camPoints.push([3.2*Math.cos(a),Math.max(-2.4,3.2*Math.sin(a))]);}
 const rodCam=profile(hone,'Came de retenue avec méplat fermé',camPoints,-1.8,3.6,steel);
 const rodShoe=box(rodTray,'Patin du ressort contre la came',46,20.5,0,6.6,.4,3.6,steel);
 const rodSpring=box(rodTray,'Ressort de retenue de tige',37.85,20.55,0,9.7,.3,3.6,steel);
 box(rodTray,'Ancrage du ressort de tige',33,20.05,0,2,1.1,4,dark);
 pin(rodTray,'Fixation du ressort de tige',33,20.1,0,.65,5);
 function poseRod(progress:number){
  const angle=-Math.PI*.56*progress;hone.rotation.z=angle;
  const bottom=23.1+Math.min(...camPoints.map(([x,y])=>x*Math.sin(angle)+y*Math.cos(angle)));
  rodShoe.position.y=bottom-.2;
  // The slender strip flexes between its fixed seat and the moving shoe (illustrative).
  const dy=bottom-20.7;rodSpring.position.y=20.55+dy/2;rodSpring.rotation.z=Math.atan2(dy,9.7);rodSpring.scale.x=Math.hypot(9.7,dy)/9.7;
 }
 // Rounded nose drops into the actual through-window of the knife clip.
 const gate=new T.Group();gate.name='Cran arrondi engagé dans la fenêtre de clip';root.add(gate);
 const roller=mesh(new T.CylinderGeometry(1.5,1.5,2.4,40),steel,gate,'Nez arrondi de retenue',3.5,0,8.8);
 const detent=new T.Group();detent.name='Lame ressort de retenue remplaçable';root.add(detent);
 const sv:number[]=[],si:number[]=[];for(let i=0;i<=30;i++){const x=-24+27.5*i/30,z=11.2-.9*i/30;for(const [y,dz] of [[-1.7,0],[1.7,0],[-1.7,.35],[1.7,.35]])sv.push(x,y,z+dz);if(i<30){const a=i*4,b=a+4;si.push(a,a+1,b,a+1,b+1,b,a+2,b+2,a+3,a+3,b+2,b+3,a,b,a+2,a+2,b,b+2,a+1,a+3,b+1,a+3,b+3,b+1);}}
 const sg=new T.BufferGeometry();sg.setAttribute('position',new T.Float32BufferAttribute(sv,3));sg.setIndex(si);sg.computeVertexNormals();const leaf=mesh(sg,steel,detent,'Lame ressort — déformation illustrative');
 const housing=profile(root,'Capot compact du ressort',[[-27,-3],[6,-3],[8,-1],[8,1],[6,3],[-27,3]],13.05,.4,shell,.15);
 for(const y of [-2.7,2.7])box(root,'Joue de cassette de retenue',-10,y,12,34,.6,1.8,shell);
 const gatePin=pin(root,'Vis de cassette borgne',-24,0,10.9,.8,1.8);
 const button=new T.Group(),plunger=new T.Group();button.name='Accès direct du doigt — aucun bouton de verrouillage';plunger.name='Course manuelle illustrée';
 // Slim longitudinal clip with two in-line fasteners; no T bridge across the case.
 const clip=new T.Group();clip.name='Clip longitudinal de l’étui';clip.position.set(5,0,-.4);root.add(clip);
 const cp=new T.Shape();cp.moveTo(44,12.7);cp.quadraticCurveTo(43,15.3,39,15.3);cp.lineTo(-25,15.3);cp.bezierCurveTo(-30,15.3,-31,13.3,-34,13.3);cp.quadraticCurveTo(-37,13.3,-40,14.5);cp.lineTo(-40.25,13.85);cp.quadraticCurveTo(-37,12.6,-34,12.6);cp.bezierCurveTo(-30.7,12.6,-29,14.6,-25,14.6);cp.lineTo(39,14.6);cp.quadraticCurveTo(42,14.6,43,12.4);cp.closePath();
 const cg=new T.ExtrudeGeometry(cp,{depth:7,bevelEnabled:false,curveSegments:24});cg.applyMatrix4(new T.Matrix4().makeBasis(new T.Vector3(1,0,0),new T.Vector3(0,0,1),new T.Vector3(0,-1,0)));mesh(cg,steel,clip,'Languette cintrée continue',0,3.5,0);
 box(clip,'Pied plein vissé',40,0,12.1,14,8,1.2,shell);
 for(const x of [44,37]){pin(clip,'Vis borgne dans le pied',x,0,12.4,.8,3.2);pin(clip,'Tête de vis',x,0,15.55,1.35,.3);}
 engrave(clip,'BIVOUAC',-10,-1.1,15.305,1.15);
 function pose(knifeOffset=0,rodProgress=0,cutaway=false,_unused=0){const lift=detentLift(knifeOffset);gate.position.z=lift;const a=sg.getAttribute('position');for(let i=0;i<a.count;i++){const t=(sv[i*3]+24)/27.5;a.setZ(i,sv[i*3+2]+lift*t*t);}a.needsUpdate=true;sg.computeVertexNormals();poseRod(rodProgress);roof.visible=ceiling.visible=skin.visible=clip.visible=housing.visible=!cutaway;root.updateMatrixWorld(true);}
 pose();return {root,exterior,floor,roof,walls,abrasives,hone,rod,rodTray,gate,gatePin,detent,clip,button,plunger,pads,ceiling,roller,leaf,rodCam,rodShoe,rodSpring,pose,dimensions:caseDimensions};
}
