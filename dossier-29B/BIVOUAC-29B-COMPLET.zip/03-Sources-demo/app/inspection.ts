import * as T from 'three';
import {neutral, type makeModel} from './model';
import {type makeSheath} from './sheath';

export type InspectionKind='fork'|'blade'|'fire'|'case'|'hone';
export type InspectionPose={kind:InspectionKind; progress:number; fork:number; press:number; automatic:boolean; blade:number; fire:number; travel:number; pop:number; hone:number};
const clamp=(v:number)=>T.MathUtils.clamp(v,0,1);
const smooth=(v:number)=>{const p=clamp(v);return p*p*(3-2*p);};
export const inspectionSteps:Record<InspectionKind,{at:number;name:string;explanation:string}[]>={
 fork:[
  {at:0,name:'1 · Poser le pouce sur les stries',explanation:'La clip est remontée près du talon pour porter le couteau plus bas dans la poche. Pose le pouce dans son ouverture centrale, sur les stries orange. Aucun embout ne dépasse.'},
  {at:.20,name:'2 · Pousser vers le bout du manche',explanation:'Fais glisser la prise vers le bout. Le téton arrondi sort de sa cuvette; une fois l’embout dégagé, tu peux le saisir. Adhérence du pouce et effort à tester sur maquette.'},
  {at:.50,name:'3 · Fourchette sortie',explanation:'La fourchette est indépendante. Le téton reste dans le manche; aucune porte ni commande extérieure.'},
  {at:.80,name:'4 · Repousser la fourchette',explanation:'L’entrée arrondie repousse le téton au passage. Continue jusqu’au fond.'},
  {at:1,name:'5 · La retenue retrouve sa cuvette',explanation:'Le téton revient dans le creux. Il faut une traction pour en ressortir : c’est une retenue résistante, pas un verrou de sécurité.'}
 ],
 blade:[{at:0,name:'1 · Saisir le dos visible',explanation:'La découpe du manche expose une partie non tranchante de la lame pour l’ouverture manuelle.'},{at:.5,name:'2 · Lame ouverte',explanation:'Observe le pivot, le crochet et la zone droite pour gratter l’allume-feu. Le verrouillage de lame reste à concevoir : cette animation ne le valide pas.'},{at:1,name:'3 · Lame refermée',explanation:'Le tranchant revient entre les platines. Tourne la vue pour inspecter l’enveloppe du manche.'}],
 fire:[{at:0,name:'1 · Prise orange arrière',explanation:'La pierre est cachée sous la coque. Sur l’autre face, pousse sa surface orange striée vers le bout du manche, puis saisis l’embout dégagé.'},{at:.5,name:'2 · Cartouche retirée',explanation:'La cartouche glisse hors du manche avant de se décaler pour montrer sa face de grattage.'},{at:1,name:'3 · Cartouche rangée',explanation:'La cartouche revient dans son rail. L’effort de retenue et l’usure sont à tester en vrai.'}],
 case:[{at:0,name:'1 · Couteau retenu dans l’étui',explanation:'Les patins guident le manche. Le cran de l’étui rencontre la petite fenêtre de la clip de poche.'},{at:.18,name:'2 · Pousser par l’avant',explanation:'L’ouverture avant permet de pousser le couteau pour faire dépasser son talon. Il ne s’agit pas d’un bouton d’éjection à ressort.'},{at:.5,name:'3 · Sortir le couteau',explanation:'Prends le talon et tire dans l’axe. La vue ouverte permet d’inspecter les appuis et le passage de la clip.'},{at:1,name:'4 · Retour au fond',explanation:'Les appuis recentrent le manche et la clip retrouve le cran. La force de retrait et le jeu réel restent à régler sur maquette.'}],
 hone:[{at:0,name:'1 · Tige repliée',explanation:'La tige conique est rangée sous l’étui, contre sa retenue. Le couteau est retiré pour dégager la manipulation.'},{at:.5,name:'2 · Tige déployée',explanation:'Observe le pivot et le passage de la tige en avançant lentement avec le curseur.'},{at:1,name:'3 · Tige retenue au repos',explanation:'La tige revient contre son sabot à ressort. La force qui l’empêche de s’ouvrir seule est à vérifier sur maquette.'}]
};
export function inspectionPose(kind:InspectionKind,progress:number):InspectionPose{
 const t=clamp(progress),p:InspectionPose={kind,progress:t,fork:0,press:0,automatic:false,blade:0,fire:0,travel:0,pop:0,hone:0};
 const cycle=t<=.5?smooth(t/.5):1-smooth((t-.5)/.5);
 if(kind==='fork'){p.fork=cycle;}else if(kind==='blade')p.blade=cycle;
 else if(kind==='fire')p.fire=cycle;
 else if(kind==='hone'){p.travel=1;p.hone=cycle;}
 else if(t<=.18)p.pop=12*smooth(t/.18);
 else if(t<=.5){p.travel=smooth((t-.18)/.32);p.pop=12*(1-p.travel);}
 else p.travel=1-smooth((t-.5)/.5);
 return p;
}

export function applyInspectionPose(model:ReturnType<typeof makeModel>,sheath:ReturnType<typeof makeSheath>,pose:InspectionPose,cutaway=false){
 model.apply(neutral);
 const inCase=pose.kind==='case'||pose.kind==='hone';
 model.setForkPose(pose.fork);
 const release=0;
 model.blade.rotation.z=-Math.PI*pose.blade;
 const slide=113*Math.min(pose.fire/.8,1),side=35*Math.max((pose.fire-.8)/.2,0);
 model.fire.position.set(slide,side,0);model.updateDetents();
 model.root.position.set(inCase?190*Math.min(pose.travel/.7,1)+pose.pop:0,inCase?-65*Math.max((pose.travel-.7)/.3,0):0,0);
 sheath.root.visible=inCase;sheath.pose(model.root.position.x,pose.hone,cutaway);
 model.root.updateMatrixWorld(true);return release;
}
