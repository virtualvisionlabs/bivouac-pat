import assert from 'node:assert/strict';
import * as T from 'three';
import {makeModel} from '../app/model.ts';
import {createManipulation,forkPoseForDrag} from '../app/manipulation.ts';
const m=createManipulation();
m.moveFork(.5);assert.equal(m.state.fork,.5,'Direct pull must not require a button');m.moveFork(2);assert.equal(m.state.fork,1);m.moveFork(-1);assert.equal(m.state.fork,0);m.moveFork(.2);assert.equal(m.state.fork,.2,'Passive detent can be pulled again');m.moveFire(2);assert.equal(m.state.fire,1);assert.equal(m.state.fork,.2);m.moveFire(-1);assert.equal(m.state.fire,0);
assert.equal(forkPoseForDrag(0),0);assert.equal(forkPoseForDrag(1),1);
let previous=0;for(let i=0;i<=1000;i++){const p=forkPoseForDrag(i/1000);assert(p>=previous&&p<=1);previous=p;}
for(const t of [.1,.2,.4,.7,.9]){const p=forkPoseForDrag(t),phase=(p-.1)/.75,s=(phase-.15)/.6;assert(Math.abs(s*s*(3-2*s)-(t-.04)/.9)<.00003,'Linear finger/slide mapping');}
const model=makeModel(),moving=[],fixed=[];model.fork.traverse(o=>{if(o.isMesh)moving.push(o)});for(const root of [model.clip,model.clipAnchors])root.traverse(o=>{if(o.isMesh)fixed.push(o)});
let gap=Infinity;
for(let i=0;i<=300;i++){model.setForkPose(forkPoseForDrag(i/300));model.root.updateMatrixWorld(true);const blockers=fixed.map(o=>({name:o.name,b:new T.Box3().setFromObject(o,true)}));for(const part of moving){const a=new T.Box3().setFromObject(part,true);for(const {name,b} of blockers){assert(!a.intersectsBox(b),`Fork meets clip/anchor: ${part.name} / ${name} at ${i}`);if(a.max.x>=b.min.x&&a.min.x<=b.max.x&&a.max.y>=b.min.y&&a.min.y<=b.max.y)gap=Math.min(gap,b.min.z-a.max.z);}}}
assert(gap>0);console.log('Nominal minimum vertical gap under clip across 301 poses: '+gap.toFixed(3)+' mm. Bounding-box check, not a tolerance or hand-clearance test.');
// A single clip bounding box spans its low toe and its raised open shoulders.
// Probe the actual underside above sampled fork vertices to resolve that conservative bound.
let surfaceGap=Infinity,surfaceProbes=0;
for(let i=0;i<=300;i++){
 model.setForkPose(forkPoseForDrag(i/300));model.root.updateMatrixWorld(true);
 for(const part of moving){const vertices=part.geometry.getAttribute('position');for(let j=0;j<vertices.count;j+=Math.max(1,Math.floor(vertices.count/30))){
  const p=part.localToWorld(new T.Vector3().fromBufferAttribute(vertices,j));
  const hit=new T.Raycaster(p,new T.Vector3(0,0,1),0,4).intersectObjects(fixed,false)[0];
  if(hit){surfaceGap=Math.min(surfaceGap,hit.distance);surfaceProbes++;}
 }}
}
assert(surfaceProbes>100);assert(surfaceGap>.3,'Insufficient sampled nominal clearance under clip');
console.log('Sampled mesh underside clearance: '+surfaceGap.toFixed(3)+' mm across '+surfaceProbes+' rays. No tolerance or flex allowance.');
console.log('PASS: passive direct pull, extraction, reinsertion, independent fire cartridge, bounds and proportional slide mapping. No browser or physical-hand test.');
