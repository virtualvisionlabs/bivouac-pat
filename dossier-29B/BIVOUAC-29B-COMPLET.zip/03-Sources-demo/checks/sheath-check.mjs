import assert from 'node:assert/strict';
import * as T from 'three';
import {makeModel,neutral} from '../app/model.ts';
import {makeSheath,caseDimensions} from '../app/sheath.ts';
import {detentLift} from '../app/retention.mjs';
const knife=makeModel(),s=makeSheath(),bounds=o=>new T.Box3().setFromObject(o,true),size=bounds(s.root).getSize(new T.Vector3());
for(const [axis,dim] of [['x','length'],['y','width'],['z','thickness']])assert(Math.abs(size[axis]-caseDimensions[dim])<.01,`${dim}: ${size[axis]}`);
const kb=bounds(knife.root);assert(kb.min.y>=-15&&kb.max.y<=15&&kb.min.z>-7.45&&kb.max.z<9.1);
assert.equal(new T.Raycaster(new T.Vector3(3.5,0,20),new T.Vector3(0,0,-1)).intersectObject(knife.clipBlade).length,0,'Clip window must be a through-hole');
assert(bounds(s.roller).min.z>7.2&&bounds(s.roller).min.z<7.85,'Rounded nose must engage the window without touching the handle');
const padBounds=s.pads.children.map(bounds);let checks=0;
// Check actual knife vertices, including the wide clip bridge, against pads and the dedicated roof channel.
for(let n=0;n<=200;n++){knife.root.position.x=n*190/200;knife.root.updateMatrixWorld(true);s.pose(knife.root.position.x);
 knife.root.traverse(p=>{if(!p.isMesh)return;const a=p.geometry.getAttribute('position');for(let i=0;i<a.count;i++){
  const v=new T.Vector3().fromBufferAttribute(a,i).applyMatrix4(p.matrixWorld);if(v.x>52)continue;checks++;
  assert(v.z>=-7.2-.002&&v.y>=-15.002&&v.y<=15.002,'Knife leaves close guide envelope');
  for(let pi=0;pi<padBounds.length;pi++){const b=padBounds[pi];if(v.x>b.min.x+.002&&v.x<b.max.x-.002&&v.y>b.min.y+.002&&v.y<b.max.y-.002&&v.z>b.min.z+.002&&v.z<b.max.z-.002){
   // A shaped pad does not occupy the empty part of its bounding box.
   assert(s.pads.children[pi].name==='Appui latéral au nez','Knife penetrates a nominal contact pad');
   const surface=new T.Raycaster(new T.Vector3(v.x,-12,v.z),new T.Vector3(0,-1,0)).intersectObject(s.pads.children[pi])[0];
   assert(surface&&v.y>=surface.point.y-.002,'Knife penetrates the shaped nose pad');
  }}
  if(v.x>=-53){const channel=v.x>=37.7?Math.abs(v.y)<13:v.x>=-5.4&&Math.abs(v.y)<4.3;assert(v.z<(channel?9.1:7.45)+.002,'Knife clip hits low ceiling');}
 }});
}
knife.root.position.x=0;knife.root.updateMatrixWorld(true);
const contacts=[[-30,15.5,4,0,-1,0,15],[28,15.5,4,0,-1,0,15],[-52,-15.8,4,0,1,0,-13.57367],[43,-15.8,4,0,1,0,-15]];
for(const [x,y,z,dx,dy,dz,wantY] of contacts){const h=new T.Raycaster(new T.Vector3(x,y,z),new T.Vector3(dx,dy,dz)).intersectObject(knife.root,true)[0];assert(h&&Math.abs(h.point.y-wantY)<.015,'Side pad does not contact the real handle');}
// Check both real surfaces, not merely the expected handle coordinate.
const nosePad=s.pads.getObjectByName('Appui latéral au nez');let noseContacts=0;
for(let x=-52.98;x<-49.51;x+=.04)for(const z of [-4,4]){
 const kh=new T.Raycaster(new T.Vector3(x,-16,z),new T.Vector3(0,1,0)).intersectObject(knife.root,true)[0];
 const ph=new T.Raycaster(new T.Vector3(x,-12,z),new T.Vector3(0,-1,0)).intersectObject(nosePad)[0];
 assert(kh&&ph&&Math.abs(kh.point.y-ph.point.y)<.002,'Rounded handle loses contact with the actual nose pad');noseContacts++;
}
for(const x of [-30,28])for(const y of [x===-30?-6.8:-10,10])for(const sign of [-1,1]){const h=new T.Raycaster(new T.Vector3(x,y,sign*20),new T.Vector3(0,0,-sign)).intersectObject(knife.root,true)[0];assert(h&&Math.abs(h.point.z-sign*7.2)<.03,'Face pad misses real handle');}
let camChecks=0,maxLift=0;
for(let n=0;n<=150;n++){const offset=n/10;knife.root.position.x=offset;knife.root.updateMatrixWorld(true);s.pose(offset);maxLift=Math.max(maxLift,detentLift(offset));
 for(let a=0;a<=90;a++){const theta=Math.PI+Math.PI*a/90,x=3.5+1.5*Math.cos(theta),z=8.8+detentLift(offset)+1.5*Math.sin(theta);
  for(const y of [-1,0,1]){const h=new T.Raycaster(new T.Vector3(x,y,20),new T.Vector3(0,0,-1)).intersectObject(knife.clipBlade)[0];if(h){assert(z>=h.point.z-.025,'Rounded catch passes through clip instead of riding over it');camChecks++;}}
 }
}
assert(detentLift(0)<.001&&maxLift>.8&&detentLift(15)===0,'Detent must seat, rise and return');
// Finger approach reaches the front of the knife, with no invented ejector or shutter.
knife.root.position.x=0;knife.root.updateMatrixWorld(true);s.pose(0);
const finger=new T.Raycaster(new T.Vector3(-80,0,4),new T.Vector3(1,0,0)),hit=finger.intersectObject(knife.root,true)[0];assert(hit);assert(!finger.intersectObjects([s.floor,s.roof,s.walls,s.pads],true).some(h=>h.distance<hit.distance-.01),'Finger approach blocked');
for(let n=0;n<=100;n++){s.pose(0,n/100);s.hone.traverse(p=>{if(!p.isMesh)return;const a=p.geometry.getAttribute('position');for(let i=0;i<a.count;i++){const v=new T.Vector3().fromBufferAttribute(a,i).applyMatrix4(p.matrixWorld);assert(v.z>-2.6&&v.z<2.6&&v.y< -19.4&&v.x>-13,'Rod hits its storage shoulder');}});}
for(const x of [-43,-22])assert.equal(new T.Raycaster(new T.Vector3(x,-27,20),new T.Vector3(0,0,-1)).intersectObject(s.root,true).length,0,'V aperture blocked');
// Closed cam seats on the spring shoe; opening forces a measurable geometric displacement.
s.pose(0,0);const closedTop=bounds(s.rodShoe).min.y;
assert(Math.abs(closedTop-bounds(s.rodCam).max.y)<.001);
assert(Math.abs(bounds(s.rod).min.x-(-9))<.01,'Keep the 50 mm rod and 4 mm gap to the V carrier');
assert(bounds(s.root).max.x<=52.001,'Upper shoulder must be flush with the mouth');
assert(s.clip.children.find(o=>o.name.startsWith('Pied plein')).position.x>35,'Clip must be anchored on the extraction end');
let springTravel=0;
for(let n=0;n<=100;n++){s.pose(0,n/100);const cam=bounds(s.rodCam),shoe=bounds(s.rodShoe);assert(Math.abs(cam.max.y-shoe.min.y)<.002,'Cam loses contact or penetrates shoe');assert(shoe.max.y<=-19.49,'Shoe hits tray floor');springTravel=Math.max(springTravel,shoe.min.y-closedTop);}
assert(springTravel>.79&&springTravel<.81,'Flat must create a retention ramp');
s.pose(0,0);
// Actual pocket clip clears the decorated roof/cassette, including its lowered tip.
const tongue=s.clip.children.find(o=>o.name.startsWith('Languette')),pa=tongue.geometry.getAttribute('position');
for(let i=0;i<pa.count;i++){const v=new T.Vector3().fromBufferAttribute(pa,i).applyMatrix4(tongue.matrixWorld);if(v.x>32)continue;const ray=new T.Raycaster(new T.Vector3(v.x,v.y,v.z-.001),new T.Vector3(0,0,1));const obstacles=s.root.children.filter(o=>o!==s.clip&&o!==s.hone);assert.equal(ray.intersectObjects(obstacles,true).length,0,'Pocket clip overlaps an exterior part');}
console.log(JSON.stringify({case_mm:size.toArray(),vertexChecks:checks,noseContacts,camChecks,maxLift,springTravel,passed:['close guide passage in 201 poses','nominal contact at four side and eight face pads','actual clip window','rounded catch in 151 positions','clear front finger approach','101 rod angles','open V slots','rod cam seating and clearance','mouth flush at 52 mm','reversed clip and exterior clearance'],limits:'Nominal geometry only. Pull force, wear, pad compression, clip fatigue and manufacturing tolerances NOT validated.'},null,2));
