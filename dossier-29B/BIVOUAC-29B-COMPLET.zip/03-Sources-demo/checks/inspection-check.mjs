import assert from 'node:assert/strict';
import * as T from 'three';
import {makeModel,neutral} from '../app/model.ts';
import {makeSheath} from '../app/sheath.ts';
import {build} from 'esbuild';
const bundle=await build({entryPoints:['app/inspection.ts'],bundle:true,platform:'node',format:'esm',write:false});
const {inspectionPose,inspectionSteps,applyInspectionPose}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const m=makeModel(),s=makeSheath(),b=o=>new T.Box3().setFromObject(o,true);
for(const kind of Object.keys(inspectionSteps)){
 let before=null;
 for(let i=0;i<=1000;i++){
  const p=inspectionPose(kind,i/1000);for(const key of ['fork','press','blade','fire','travel','hone'])assert(p[key]>=0&&p[key]<=1);
  if(before)for(const key of ['fork','press','blade','fire','travel','hone'])assert(Math.abs(p[key]-before[key])<.07,'Discontinuity in '+kind+'/'+key);
  before=p;
 }
}
let probes=0,maxFork=0,maxFire=0;
function clearance(nose,receiver){const vertices=nose.geometry.getAttribute('position');for(let i=0;i<vertices.count;i++){const v=nose.localToWorld(new T.Vector3().fromBufferAttribute(vertices,i));const hit=new T.Raycaster(new T.Vector3(v.x,-20,v.z),new T.Vector3(0,1,0)).intersectObject(receiver)[0];if(hit){probes++;assert(v.y<=hit.point.y+.035,`Rounded nose crosses receiver: ${v.toArray()} / ${hit.point.toArray()}`);}}}
for(let i=0;i<=300;i++){
 applyInspectionPose(m,s,inspectionPose('fork',i/300));maxFork=Math.max(maxFork,m.forkDetent.restY-m.forkDetent.nose.position.y);clearance(m.forkDetent.nose,m.forkReceiver);
 applyInspectionPose(m,s,inspectionPose('fire',i/300));maxFire=Math.max(maxFire,m.fireDetent.restY-m.fireDetent.nose.position.y);clearance(m.fireDetent.nose,m.fire.getObjectByName('Prise de cartouche affleurante'));
}
assert(maxFork>.5&&maxFire>.5);assert(probes>100);m.apply(neutral);
assert(Math.abs(m.forkDetent.restY-m.forkDetent.nose.position.y)<.02);assert(Math.abs(m.fireDetent.restY-m.fireDetent.nose.position.y)<.02);
assert.equal(m.snapButtons.length,0);assert(!m.root.getObjectByName('Bouton orange de déverrouillage'));
assert.equal(b(m.clip).max.x,57);assert.equal(b(m.forkGrip).max.x,60);assert.equal(b(m.fireGrip).max.x,60);
for(const x of [45,46,49,52,55,58,59])for(const y of [-3.5,0,3.5]){const hit=new T.Raycaster(new T.Vector3(x,y,20),new T.Vector3(0,0,-1)).intersectObject(m.root,true)[0];assert(hit&&['Prise orange de 16 mm','Nervure de poussée fourchette'].includes(hit.object.name),'Heel clip opening must leave thumb pad exposed');}
console.log(JSON.stringify({checks:'continuous inspection timelines, passive rounded noses on both accessories, return to recess, absent button, flush accessible thumb pads',sampledContactProbes:probes,forkCamTravel_mm:maxFork,fireCamTravel_mm:maxFire,clipOpeningWidth_mm:12,limits:'Nominal geometry sampling only; no force, fatigue, glove or manufacturing tolerance validation.'},null,2));
