import fs from 'node:fs';
import path from 'node:path';
import * as T from 'three';
import {GLTFExporter} from 'three/examples/jsm/exporters/GLTFExporter.js';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {makeModel,neutral} from '../app/model.ts';
import {makeSheath} from '../app/sheath.ts';
// Node adapter: exporter assembles GLB using Blob and FileReader.
globalThis.FileReader=class {async readAsArrayBuffer(blob){this.result=await blob.arrayBuffer();this.onloadend?.();}async readAsDataURL(blob){this.result='data:'+blob.type+';base64,'+Buffer.from(await blob.arrayBuffer()).toString('base64');this.onloadend?.();}};
const out=process.argv[2]||'exports';fs.mkdirSync(out,{recursive:true});const report=[];
async function save(name,objects){
 const root=new T.Group();root.name='BIVOUAC_29_metres';root.scale.setScalar(.001);
 for(const obj of objects)root.add(obj.clone(true));
 // glTF standard does not support Three.js bumpMap. Keep base PBR appearance; original grain is in source.
 root.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.bumpMap=null;}});
 const data=await new GLTFExporter().parseAsync(root,{binary:true});fs.writeFileSync(path.join(out,name+'.glb'),Buffer.from(data));
 const loaded=await new GLTFLoader().parseAsync(data,'');let meshes=0;loaded.scene.traverse(o=>{if(o.isMesh)meshes++;});
 const bounds=new T.Box3().setFromObject(loaded.scene,true).getSize(new T.Vector3()).multiplyScalar(1000);
 if(!meshes||!bounds.toArray().every(Number.isFinite))throw Error('Invalid export '+name);
 report.push({file:name+'.glb',meshes,dimensions_mm:bounds.toArray(),bytes:data.byteLength});
}
const m=makeModel(),s=makeSheath();
await save('01-couteau-ferme',[m.root]);
m.apply({...neutral,blade:true});await save('02-couteau-ouvert',[m.root]);
m.apply({...neutral,blade:true,fork:true,fire:true,exploded:true});await save('03-couteau-vue-eclatee',[m.root]);
m.apply(neutral);s.pose(0,0);await save('04-etui-tige-repliee',[s.root]);
s.pose(0,1);await save('05-etui-tige-deployee',[s.root]);
s.pose(0,0);await save('06-ensemble-range',[m.root,s.root]);
await save('07-fourchette',[m.fork]);await save('08-cartouche-allume-feu',[m.fire]);await save('09-lame',[m.blade]);await save('10-tige-aiguisage',[s.hone]);
await save('11-clip-couteau-et-ancrages',[m.clip,m.clipAnchors]);m.cover.visible=false;m.fireCover.visible=false;m.front.getObjectByName('Contour évidé avant').visible=false;await save('12-couteau-retenues-visibles',[m.root]);
fs.writeFileSync(path.join(out,'verification-exports.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
