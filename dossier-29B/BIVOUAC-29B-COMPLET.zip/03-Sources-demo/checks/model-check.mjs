import assert from 'node:assert/strict';
import * as T from 'three';
import {makeModel,neutral,canReleaseFork} from '../app/model.ts';
const m=makeModel();const bounds=o=>new T.Box3().setFromObject(o,true);const size=o=>bounds(o).getSize(new T.Vector3());
const closed=size(m.root);assert(Math.abs(closed.x-120)<.01);assert(Math.abs(closed.z-16.1)<.01);
const clip=m.root.getObjectByName('Clip fine indépendante');clip.removeFromParent();m.clipAnchors.removeFromParent();const body=size(m.root);assert(Math.abs(body.z-14.4)<.01);m.front.add(clip);m.front.add(m.clipAnchors);
assert(!m.root.getObjectByName('Rallonge tournante à 180 degrés'));assert(!m.root.getObjectByName('Vis de charnière indicative'));
const rod=m.root.getObjectByName('FireSteel Miniature 3,8 x 50,8 mm');const rodSize=size(rod);assert(Math.abs(rodSize.x-50.8)<.01&&Math.abs(rodSize.z-3.8)<.01);
const ray=new T.Raycaster(new T.Vector3(10,0,-20),new T.Vector3(0,0,1));const hits=ray.intersectObject(m.fire,true);assert.equal(hits[0].object.name,rod.name,'Scraping face must remain exposed');
const bladeMesh=m.blade.getObjectByName('Lame drop-point à facettes');const liner=m.root.getObjectByName('Platine avant');const positions=bladeMesh.geometry.getAttribute('position');
for(let i=0;i<positions.count;i++){const local=new T.Vector3().fromBufferAttribute(positions,i);bladeMesh.localToWorld(local);const probe=new T.Raycaster(new T.Vector3(local.x,local.y,12),new T.Vector3(0,0,-1));if(!probe.intersectObject(liner).length)assert(local.x>=-40&&local.x<=22&&local.y>=-16.01&&local.y<=-11,'Only the smooth non-cutting spine may project beyond the closed handle');}
assert(Math.abs(closed.y-30)<.01,'Smooth spine envelope');
const openingRay=new T.Raycaster(new T.Vector3(-20,-30,0),new T.Vector3(0,1,0));assert(openingRay.intersectObject(m.root,true)[0].object.parent===m.blade,'Exposed spine inaccessible');
const hookRay=new T.Raycaster(new T.Vector3(26,-8,10),new T.Vector3(0,0,-1));assert.equal(hookRay.intersectObject(m.blade,true).length,0,'Gut hook filled by a blade facet');
// The hook mouth faces the heel: empty behind the lip, solid in the fore-blade.
assert.equal(new T.Raycaster(new T.Vector3(25,-10,10),new T.Vector3(0,0,-1)).intersectObject(m.blade,true).length,0,'Hook mouth must face the handle');
assert(new T.Raycaster(new T.Vector3(33,-7,10),new T.Vector3(0,0,-1)).intersectObject(bladeMesh).length>0,'Fore-blade must continue beyond the hook');
const compact=size(m.fork);assert(compact.x>=106.9&&compact.x<=107.1);
const forkBounds=bounds(m.fork);assert(forkBounds.min.z>2.3);assert(forkBounds.max.z<7.2);assert(forkBounds.min.y>-13.6&&forkBounds.max.y<13.6);
// The neck bends before the teeth begin, while the grip stays planar.
const head=m.forkHead.geometry.getAttribute('position');
assert(Math.abs(head.getZ(0)+.45)<.001);const handle=[];for(let i=0;i<head.count;i+=4)if(head.getX(i)>=-8)handle.push(head.getZ(i));assert(handle.every(z=>Math.abs(z)<.001));
for(const tooth of m.teeth){const attr=tooth.geometry.getAttribute('position');assert(Math.abs(attr.getZ(attr.count-1)-attr.getZ(3)+.55)<.001);}
// Real downward bores: ray through the centre sees the solid floor below, not a painted dot.
assert.equal(m.socketCenters.length,4);
for(const y of m.socketCenters){const testRay=new T.Raycaster(new T.Vector3(-47,y,10),new T.Vector3(0,0,-1));assert.equal(testRay.intersectObject(m.sockets).length,0);const floor=m.root.getObjectByName('Insert de logement POM-C');assert(testRay.intersectObject(floor).length>0);}
// Sample the rigid-body release and insertion path. Bottom vertices must clear
// the real ramp mesh; all fork vertices overlapping the cover must stay below it.
let rampProbes=0;
for(let step=0;step<=400;step++){
 m.setForkPose(step/400);m.root.updateMatrixWorld(true);
 if(step/400<=.15)assert(Math.abs(m.fork.position.x)<.002,'Must lift before sliding');
 for(const part of [...m.teeth,m.forkHead]){const a=part.geometry.getAttribute('position');for(let i=0;i<a.count;i++){
  const v=part.localToWorld(new T.Vector3().fromBufferAttribute(a,i));
  if(v.x<60){assert(v.z<6.6,'Fork hits cover');assert(v.z>2.3,'Fork crosses floor');}
  if(i%4<2&&v.x>=-49.8&&v.x<=-43.5&&Math.abs(v.y)<8){const probe=new T.Raycaster(new T.Vector3(v.x,v.y,10),new T.Vector3(0,0,-1));const hits=probe.intersectObject(m.sockets);if(hits.length){rampProbes++;assert(v.z>=hits[0].point.z-.015,`Ramp contact at step ${step}: ${v.toArray()} vs ${hits[0].point.z}`);}}
 }}

}
assert(rampProbes>0);
m.apply(neutral);
// Seated tips fall below the top rim of the wells, above their closed floor.
for(const tooth of m.teeth){const a=tooth.geometry.getAttribute('position'),v=tooth.localToWorld(new T.Vector3().fromBufferAttribute(a,a.count-4));assert(v.z>2.3&&v.z<2.95);}
// The index hollow is present, yet the approved closed blade stays enclosed.
const indexProbe=new T.Raycaster(new T.Vector3(-35,-13,12),new T.Vector3(0,0,-1));assert.equal(indexProbe.intersectObject(liner).length,0);
const gripProbe=new T.Raycaster(new T.Vector3(-35,-9,12),new T.Vector3(0,0,-1));assert(gripProbe.intersectObject(liner).length>0);
// Cover must actually sit above the fork, including after applying an animated state.
assert(Math.abs(bounds(m.cover).min.z-6.6)<.001);
for(const part of [...m.teeth,m.forkHead]){const a=part.geometry.getAttribute('position');for(let i=0;i<a.count;i++){const v=part.localToWorld(new T.Vector3().fromBufferAttribute(a,i));const probe=new T.Raycaster(new T.Vector3(v.x,v.y,20),new T.Vector3(0,0,-1));const hits=probe.intersectObject(m.cover);assert((hits.length>0&&hits[0].point.z>v.z)||(v.x>=43.7&&Math.abs(v.y)<=5.2),'Stored fork visible outside orange grip');}}
// End aperture is physically opaque when closed, not merely hidden by camera position.
for(let y=-7;y<=7;y+=1)for(let z=2.5;z<=6.4;z+=.3){const probe=new T.Raycaster(new T.Vector3(80,y,z),new T.Vector3(-1,0,0));assert(probe.intersectObjects([m.tailCap,...m.snapButtons],true).length>0,'Tail closure leaves an open view into the tunnel');}
for(const screw of m.clipScrews){const b=bounds(screw);assert(b.min.y>8.5||b.max.y< -8.5,'Clip screw enters fork passage');assert(b.min.z>4.1,'Screw pierces the blind insert floor');assert(b.max.z>8.1,'Screw does not reach clip foot');}
for(let i=0;i<=400;i++){m.setForkPose(i/400);m.root.updateMatrixWorld(true);m.fork.traverse(part=>{if(part.isMesh)for(const screw of m.clipScrews)assert(!bounds(part).intersectsBox(bounds(screw)),'Clip screws obstruct fork withdrawal');});}
m.apply(neutral);
assert.equal(m.tailCap.parent,m.fork);assert(!m.root.getObjectByName('Volet affleurant du logement'));
const cb=bounds(m.clipBlade);assert(Math.abs(cb.min.y+cb.max.y)<.001&&Math.abs(cb.max.y-cb.min.y-20)<.001);
assert(Math.abs(m.clipScrews[0].position.y+m.clipScrews[1].position.y)<.001);assert.equal(m.clipScrews[0].position.x,m.clipScrews[1].position.x);
// Study 22: no exterior button or rocker linkage; passive rounded detents.
assert.equal(m.snapButtons.length,0);assert(!m.root.getObjectByName('Bouton orange de déverrouillage'));assert.equal(m.clipScrews[0].position.x,54);assert(canReleaseFork(false,false));
m.apply(neutral);assert(m.forkDetent&&m.fireDetent);assert.equal(m.forkGrip.parent,m.tailCap);assert.equal(m.fireGrip.parent,m.fire);
const flat=m.blade.getObjectByName('Zone droite de grattage, sans encoche').geometry.getAttribute('position');for(let i=0;i<flat.count;i++)assert(Math.abs(flat.getY(i)+13.005)<.001);
const fireBounds=bounds(m.fire);assert(fireBounds.max.z< -2.7);assert(fireBounds.min.z> -7.2);assert(fireBounds.min.y> -6&&fireBounds.max.y<6);
// The stored rod is hidden by an actual opaque skin, while the orange grip stays exposed.
for(const x of [-14,0,15,30])for(const y of [-1,0,1]){
 const probe=new T.Raycaster(new T.Vector3(x,y,-20),new T.Vector3(0,0,1));
 assert(probe.intersectObject(m.root,true)[0].object===m.fireCover,'Stored rod visible through rear face');
}
for(const x of [38,42,48,54,59]){
 const probe=new T.Raycaster(new T.Vector3(x,2,-20),new T.Vector3(0,0,1));
 assert(['Prise de cartouche affleurante','Nervure de poussée allume-feu'].includes(probe.intersectObject(m.root,true)[0].object.name));
}
for(const y of [-4,0,4])for(const z of [-6.4,-4,-3.1]){
 const probe=new T.Raycaster(new T.Vector3(70,y,z),new T.Vector3(-1,0,0));
 assert(['Prise de cartouche affleurante','Lèvre de traction allume-feu'].includes(probe.intersectObject(m.root,true)[0].object.name),'Rear mouth left open');
}
const rails=m.back.children.filter(o=>o.name==='Rail de cartouche encastré');
for(let step=0;step<=200;step++){
 m.fire.position.x=113*step/200;m.root.updateMatrixWorld(true);
 m.fire.traverse(part=>{if(!part.isMesh)return;for(const rail of rails)assert(!bounds(part).intersectsBox(bounds(rail)),'Cartouche hits guide rail');
  const a=part.geometry.getAttribute('position');for(let i=0;i<a.count;i++){
   const v=part.localToWorld(new T.Vector3().fromBufferAttribute(a,i));if(v.x>60)continue;
   const probe=new T.Raycaster(new T.Vector3(v.x,v.y,-20),new T.Vector3(0,0,1));
   if(probe.intersectObject(m.fireCover).length)assert(v.z> -6.7,'Cartouche crosses opaque skin');
   assert(v.z< -2.7,'Cartouche crosses internal floor');
  }
 });
}
m.apply({...neutral,fire:true});
const exposed=new T.Raycaster(new T.Vector3(123,35,-20),new T.Vector3(0,0,1));
assert(exposed.intersectObject(m.root,true)[0].object===m.fireRod,'Extracted scraping face covered');
m.apply(neutral);
for(let deg=0;deg<=180;deg+=5){m.blade.rotation.z=-deg*Math.PI/180;m.root.updateMatrixWorld(true);const blade=bounds(m.blade);assert(blade.min.z> -1.25&&blade.max.z<1.25);assert(forkBounds.min.z>blade.max.z);assert(fireBounds.max.z<blade.min.z);}
m.apply({...neutral,fork:true});assert(Math.abs(size(m.fork).x-compact.x)<.001,'Rigid fork changes length after removal');
m.apply({...neutral,blade:true,fire:true,fork:true,exploded:true});m.root.traverse(o=>{assert(o.position.toArray().every(Number.isFinite));});
console.log(JSON.stringify({closed_mm:closed.toArray(),body_thickness_mm:body.z,fork_compact_mm:compact.x,checked:'closed cutting edge enclosed with exposed non-cutting spine, curved neck and downward fork head, real downward recesses, 401 release/insertion poses sampled against ramp and cover, seated tips, enlarged manual opening relief, real front cover and opaque tail closure, symmetric centred clip, offset screws clear of fork, flush cap, passive rounded detents, flush thumb pads and heel-mounted open-shoulder clip, straight scraping surface, sourced rod dimensions, exposed scraping face, envelopes, layer clearances, blade layer across 37 poses, rigid fork length invariant',limits:'Not a mechanical lock, stress, contact or spark-performance simulation'},null,2));

