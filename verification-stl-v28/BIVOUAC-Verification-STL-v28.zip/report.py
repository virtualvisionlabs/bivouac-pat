"""Generate a professional review and portable audit handoff (no new STL)."""
from pathlib import Path
import hashlib,json,shutil,zipfile
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

OUT=Path('../BIVOUAC-Verification-STL-v28');R=json.loads((OUT/'controle-numerique.json').read_text(encoding='utf-8'))
for n,f in [('A','arial.ttf'),('B','arialbd.ttf')]:pdfmetrics.registerFont(TTFont(n,'C:/Windows/Fonts/'+f))
pdfmetrics.registerFontFamily('A',normal='A',bold='B')
GREEN=colors.HexColor('#193a32');INK=colors.HexColor('#25392f')
style=ParagraphStyle('body',fontName='A',fontSize=10.5,leading=15,textColor=INK)
small=ParagraphStyle('small',parent=style,fontSize=8.5,leading=11.5)
c=canvas.Canvas(str(OUT/'Verification-STL-complet-v28.pdf'),pagesize=(595.28,841.89))
c.setTitle('BIVOUAC — Vérification du STL de maquette v28');c.setAuthor('Documentation technique — analyse assistée par IA')
y=0;n=0
def footer():
 c.setFillColor(INK);c.setFont('A',8);c.drawString(42,31,'BIV-STL-28 / A · 9 octobre 2026 · Vérification numérique, sans essai physique');c.drawRightString(553,31,str(n))
def page(title):
 global n,y
 if n:footer();c.showPage()
 n+=1;c.setFillColor(GREEN);c.rect(0,793,596,49,fill=1,stroke=0);c.setFillColor(colors.white);c.setFont('B',11);c.drawString(42,813,'BIVOUAC / CONTRÔLE DE MAQUETTE');c.setFont('A',9);c.drawRightString(553,813,'V28 · RAPPORT A')
 c.setFillColor(INK);c.setFont('B',21);c.drawString(42,746,title);y=722
def p(s,tiny=False):
 global y
 ob=Paragraph(s,small if tiny else style);_,h=ob.wrap(511,700);y-=h;ob.drawOn(c,42,y);y-=11;assert y>58,(n,y)
def h(s):
 global y
 y-=7;c.setFillColor(GREEN);c.setFont('B',12);c.drawString(42,y,s);y-=23
def table(rows,widths):
 global y
 cells=[[Paragraph(str(v),small) for v in row] for row in rows]
 ob=Table(cells,colWidths=widths);ob.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dce8df')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f2f5f2'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]));_,ht=ob.wrap(511,700);y-=ht;ob.drawOn(c,42,y);y-=12;assert y>58

page('Résultat de la vérification')
p('<b>Dimensions cohérentes. Préparation du maillage à terminer avant impression.</b> Le fichier reçu ne peut pas être confirmé comme un unique solide fusionné prêt à imprimer. Cette réserve concerne la préparation du STL, pas le choix esthétique du produit.')
p('Objet examiné : couteau fermé v28, maquette inerte destinée à la prise en main. Aucune pièce mobile, aucune utilisation coupante. Le fichier reçu est conservé sans modification; aucun nouveau STL n’est produit, conformément à la demande jointe.')
table([['Contrôle','Constat'],['Dimensions du STL','120,029 × 30,140 × 16,100 mm'],['GLB v28 de référence','120,000 × 30,000 × 16,100 mm'],['Écart d’enveloppe','+0,029 mm en longueur; +0,140 mm en hauteur; épaisseur identique à l’arrondi.'],['Triangles / coordonnées','232 112 triangles; aucune coordonnée non finie.'],['Fermeture / orientation','Test « watertight » positif; orientations cohérentes après soudage des sommets identiques.'],['Continuité du maillage','318 composantes surfaciques; 43 ont un volume nul à 10⁻⁹ mm³ près.']],[174,337])
h('Ce que signifie le résultat')
p('Un STL peut réunir plusieurs enveloppes fermées sans que leurs volumes soient fusionnés. Le résultat « étanche » ne démontre donc ni un seul bloc propre, ni l’absence de surfaces internes, de chevauchements ou de détails flottants.')
p('Un diagnostic complémentaire d’union des 275 composantes de volume non nul conserve 236 composantes. Ce calcul n’a pas été exporté comme modèle réparé. Certaines composantes peuvent être internes ou emboîtées : ces nombres ne signifient pas qu’autant de pièces tomberaient de l’imprimante.')
p('<b>Conclusion :</b> demander une préparation en solide unique adapté à la maquette, puis un contrôle couche par couche dans le trancheur. Un trancheur peut résoudre certains chevauchements; ce comportement n’a pas été vérifié ici.')

page('Impression FDM : points sensibles')
p('Le fichier contient 119 composantes dont au moins une dimension de boîte englobante est inférieure à 0,1 mm, avec notamment des éléments de 0,003 mm. Il s’agit d’un indicateur de détails fins, et non d’une mesure exhaustive d’épaisseur de paroi. Ces éléments ne doivent pas être considérés comme des détails FDM garantis avec une buse de 0,4 mm.')
h('Orientation proposée à l’atelier')
p('<b>À plat sur le grand côté opposé à la clip, clip vers le haut.</b> Dans le repère reçu : Z positif vers le haut; translater la pièce d’environ +7,2 mm en Z pour amener le point le plus bas au plateau. Cette orientation limite la hauteur à environ 16,1 mm et préserve mieux le côté de la clip.')
p('Le contact initial n’est pas une grande face plane garantie. Vérifier la première couche et prévoir les supports locaux nécessaires sous les reliefs du côté posé au plateau. Les zones en porte-à-faux sous la clip et ses épaules doivent être contrôlées séparément; éviter de supposer qu’elles se pontent correctement ou que les supports seront faciles à retirer.')
p('La clip est une forme de maquette : ne pas la plier ni tester son élasticité comme une clip métallique. Ses zones fines risquent de casser au retrait des supports. Prévoir une prise en main sans mise en charge de la clip.')
h('Coupes du fichier effectivement reçu')
c.drawImage(str(OUT/'coupes-du-stl.png'),42,132,width=511,height=225);y=119
p('Les lignes représentent les surfaces traversées par les plans de coupe. Elles montrent des interfaces internes; ce ne sont ni des couches de matière ni une simulation du trancheur.',True)

page('Réglages et évaluation du poids')
p('Les valeurs suivantes sont des <b>points de départ proposés</b> pour une maquette PLA, à adapter par l’atelier après préparation géométrique et selon son matériel. Aucun profil machine ni G-code n’est fourni.')
table([['Paramètre','Proposition'],['Échelle','100 %, dimensions en millimètres. Le format STL ne fixe pas lui-même l’unité.'],['Buse / couches','Buse 0,4 mm; couches 0,16 à 0,20 mm.'],['Parois / dessus-dessous','4 périmètres; environ 0,8 à 1,0 mm de couches pleines en haut et en bas.'],['Remplissage initial','30 % gyroid pour un premier essai de forme et de prise en main.'],['Supports','À décider dans l’aperçu tranché, en particulier sous la clip et les reliefs.'],['Températures / adhérence','Profil PLA éprouvé de l’atelier; ajuster l’adhérence après inspection de la première couche.']],[174,337])
h('Un pourcentage ne garantit pas un poids réaliste')
p('La masse finale du couteau métallique n’est pas définie. Aucun taux de remplissage ne peut donc reproduire son poids avec certitude. Le trancheur doit annoncer la masse estimée de la pièce, puis une balance doit confirmer la masse imprimée.')
p('À titre de borne supérieure, toute la boîte de 120,029 × 30,140 × 16,100 mm remplie de PLA à 1,24 g/cm³ pèserait environ <b>72,2 g</b>. Le couteau réel en plastique occupe moins que cette boîte. Ce chiffre n’est pas une prédiction de masse, et exclut supports et bordure [S4].')
p('Le volume brut affiché par une lecture du STL additionne des enveloppes : il peut compter plusieurs fois des zones superposées. Il ne faut pas le convertir directement en poids. Si une masse cible supérieure est souhaitée plus tard, une maquette lestée demanderait une adaptation distincte et une répartition du lest réfléchie.')
p('Le remplissage affecte la consommation et la masse; le nombre de périmètres est aussi déterminant pour la résistance. Les recommandations générales de Prusa appuient ce choix de réglages, sans valider cette géométrie particulière [S1–S3].',True)

page('Transmission et traçabilité')
h('Travail demandé avant lancement de l’impression')
p('1. Conserver une copie du STL reçu et le design extérieur v28. Préparer une maquette inerte réellement unifiée, en supprimant les enveloppes sans volume et en traitant les surfaces internes ainsi que les détails sous-résolution. Ne pas laisser la réparation automatique décider seule des petits jeux à fermer.')
p('2. Vérifier les dimensions et le maintien des rainures, arrondis et volumes de clip après cette préparation. Toute simplification extérieure doit être signalée au responsable du projet.')
p('3. Trancher avec le profil de la machine prévue. Inspecter toutes les couches : première couche, îlots, continuité, clip, supports et accès pour leur retrait. Confirmer consommation et masse estimée avant impression.')
p('4. Imprimer une seule maquette de contrôle, mesurer longueur/hauteur/épaisseur et masse, puis vérifier la prise en main. Aucun essai de fonctionnement mécanique n’est attendu.')
h('Périmètre des preuves')
p('Contrôles réalisés : lecture du STL, soudage de sommets coïncidents, dimensions, fermeture topologique, orientations, composantes, diagnostic d’union volumique et comparaison des enveloppes avec le GLB v28 d’origine. Aucun essai dans un trancheur ni essai physique. Aucun contrôle exhaustif de collision ou d’auto-intersection. La comparaison dimensionnelle ne prouve pas une identité de toutes les surfaces.',True)
p('Original : <b>maquette-couteau-ferme.stl</b>, 11 605 684 octets.<br/>SHA-256 : '+R['input_sha256'][:32]+'<br/>'+R['input_sha256'][32:]+'<br/>L’archive de retour conserve les mêmes octets sous un nom mentionnant ORIGINAL-NON-VALIDE.',True)
h('Références techniques consultées le 9 octobre 2026')
for label,title,url in [
 ('S1','Prusa — Layers and perimeters','https://help.prusa3d.com/article/layers-and-perimeters_1748'),
 ('S2','Prusa — Support material','https://help.prusa3d.com/article/support-material_1698'),
 ('S3','Prusa — Infill','https://help.prusa3d.com/article/infill_42'),
 ('S4','Prusament PLA — fiche technique, densité 1,24 g/cm³','https://prusament.com/wp-content/uploads/2022/10/PLA_Prusament_TDS_2021_10_EN.pdf'),
 ('S5','Prusa — Split to objects/parts : enveloppes dans un fichier','https://help.prusa3d.com/article/split-to-objects-parts_1751')]:
 p(f'[{label}] <link href="{url}" color="#225c42">{title}</link>',True)
footer();c.save()

text='''VÉRIFICATION DU STL COMPLET V28 — 9 OCTOBRE 2026

RÉSULTAT
Les dimensions sont cohérentes : 120,029 x 30,140 x 16,100 mm.
Le GLB v28 d’origine mesure 120 x 30 x 16,1 mm.
Le STL n’est toutefois pas confirmé comme un seul solide fusionné prêt à imprimer.

CONSTATS REPRODUCTIBLES
232 112 triangles. Fermeture topologique et orientation cohérente positives.
318 composantes surfaciques après soudage des sommets coïncidents.
43 composantes de volume nul (seuil 1e-9 mm3).
119 composantes avec une dimension de boîte englobante inférieure à 0,1 mm.
Union diagnostique des 275 composantes non nulles : 236 composantes restantes.
Les coques internes/emboîtées ne sont pas nécessairement des pièces imprimées
séparément. Ces résultats ne permettent cependant pas d’affirmer « solide unique ».

ACTION DEMANDÉE
Préparer un solide de maquette inerte, traiter les surfaces internes, les éléments
sans volume et les détails trop fins; préserver la silhouette et documenter toute
simplification. Contrôler ensuite toutes les couches dans le trancheur de l’atelier.

ORIENTATION PROPOSÉE
Grand côté opposé à la clip vers le plateau; clip en haut (Z positif du fichier).
Supports locaux à contrôler sous la clip et les reliefs. Ne pas forcer la clip PLA.

RÉGLAGES DE DÉPART APRÈS PRÉPARATION
PLA, buse 0,4 mm, couche 0,16–0,20 mm, 4 périmètres, 0,8–1,0 mm dessus/dessous,
30 % de gyroid. Le profil réel et les supports restent à valider par l’imprimeur.
La masse métallique cible n’est pas définie; ne pas promettre un poids réaliste
par le seul taux de remplissage. Lire la masse du trancheur et peser la maquette.

CONTENU DU RETOUR
PDF de 4 pages : réponses aux cinq questions et références.
controle-numerique.json : résultats détaillés et empreintes des fichiers.
coupes-du-stl.png : coupes des surfaces reçues, pas une simulation d’impression.
maquette-couteau-ferme-ORIGINAL-NON-VALIDE.stl : original inchangé, pour traçabilité.
audit.py et report.py : scripts de contrôle et génération du compte rendu.

Aucun nouveau STL ni changement du design. Aucun essai de trancheur ou impression.
Le fichier original n’est pas un bon-à-imprimer. Ce rapport ne concerne pas la
fabrication ou le fonctionnement d’un couteau métallique.
'''
(OUT/'LIRE-EN-PREMIER.txt').write_text(text,encoding='utf-8')
for name in ['audit.py','report.py']:shutil.copy2(Path(__file__).parent/name,OUT/name)
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='MANIFESTE-SHA256.txt')
(OUT/'MANIFESTE-SHA256.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in files)+'\n',encoding='utf-8')
dest=OUT.parent/'BIVOUAC-Verification-STL-v28.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(OUT.iterdir()):z.write(p,p.name)
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print('PDF:',n,'pages; ZIP:',dest.stat().st_size,'octets')
