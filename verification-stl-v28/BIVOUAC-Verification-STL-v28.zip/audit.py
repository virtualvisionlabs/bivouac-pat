"""Read-only audit of an inert closed-knife mockup; never exports repaired geometry."""
from pathlib import Path
import argparse, hashlib, io, json, warnings, zipfile
import numpy as np
import trimesh
import manifold3d as M

ap=argparse.ArgumentParser()
ap.add_argument('request_zip'); ap.add_argument('reference_zip'); ap.add_argument('output')
a=ap.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.request_zip) as z:
    raw=z.read('demande-verification-stl-complet/maquette-couteau-ferme.stl')
(out/'maquette-couteau-ferme-ORIGINAL-NON-VALIDE.stl').write_bytes(raw)
m=trimesh.load_mesh(io.BytesIO(raw),file_type='stl',process=True)
with warnings.catch_warnings():
    warnings.simplefilter('ignore',RuntimeWarning)
    parts=m.split(only_watertight=False)
    part_data=[{'id':i,'triangles':len(c.faces),'watertight':bool(c.is_watertight),
                'volume_mm3':float(c.volume),'bounds_mm':c.bounds.tolist(),
                'extents_mm':c.extents.tolist()} for i,c in enumerate(parts)]
solids=[]; statuses={}; excluded=[]
for i,c in enumerate(parts):
    if abs(c.volume)<1e-9: excluded.append(i); continue
    obj=M.Manifold(M.Mesh64(np.asarray(c.vertices,dtype=np.float64),np.asarray(c.faces,dtype=np.uint64)))
    status=str(obj.status()); statuses[status]=statuses.get(status,0)+1
    assert obj.status()==M.Error.NoError,(i,status)
    solids.append(obj)
u=M.Manifold.batch_boolean(solids,M.OpType.Add)
assert u.status()==M.Error.NoError
uc=u.decompose()
union_parts=sorted([{'volume_mm3':c.volume(),'bounds_mm':list(c.bounding_box())} for c in uc],key=lambda c:-c['volume_mm3'])
with zipfile.ZipFile(a.reference_zip) as z:
    reference=z.read('paquet-frere-v28/glb/01-couteau-ferme.glb')
s=trimesh.load(io.BytesIO(reference),file_type='glb',force='scene')
ref=s.extents*1000
r={'date':'2026-10-09','scope':'Maquette inerte fermee uniquement; aucun changement de geometrie',
   'input_sha256':hashlib.sha256(raw).hexdigest(),'input_bytes':len(raw),
   'reference_glb_sha256':hashlib.sha256(reference).hexdigest(),
   'units':'STL interprete en mm selon la demande; GLB converti de m en mm',
   'vertices_after_welding':len(m.vertices),'triangles':len(m.faces),
   'bounds_mm':m.bounds.tolist(),'extents_mm':m.extents.tolist(),
   'reference_glb_v28_size_mm':ref.tolist(),'delta_size_vs_reference_mm':(m.extents-ref).tolist(),
   'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),
   'nonfinite_vertices':int((~np.isfinite(m.vertices)).sum()),
   'degenerate_triangles_area_under_1e_10':int((m.area_faces<1e-10).sum()),
   'connected_surface_components':len(parts),'zero_volume_components':len(excluded),
   'components_bbox_thinner_than_0_1_mm':int(sum(min(c.extents)<.1 for c in parts)),
   'component_volume_sum_NOT_physical_volume_mm3':float(m.volume),
   'union_diagnostic':{'excluded_zero_volume_ids':excluded,'input_statuses':statuses,
        'status':str(u.status()),'connected_components':len(uc),'volume_mm3':u.volume(),
        'largest_components':union_parts[:10],'geometry_exported':False,
        'note':'Diagnostic seulement; aucune fermeture de jeux ni ajout de matiere.'},
   'parts':part_data,'bounding_box_full_PLA_mass_upper_bound_g':float(np.prod(m.extents)/1000*1.24),
   'slicer_tested':False,'physical_print_tested':False,'self_intersection_exhaustive_test':False,
   'verdict':'Preparation geometrique et verification dans le trancheur requises avant impression.',
   'versions':{'trimesh':trimesh.__version__,'numpy':np.__version__}}
(out/'controle-numerique.json').write_text(json.dumps(r,indent=2,ensure_ascii=False),encoding='utf-8')
# Cross-sections of input surface triangles, not a slicer or a print path.
from PIL import Image,ImageDraw,ImageFont
im=Image.new('RGB',(1500,660),'white');draw=ImageDraw.Draw(im)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',26)
for cy,normal,coords,title in [(205,[0,1,0],[0,2],'Coupe longitudinale à Y = 0 (axes X/Z)'),(525,[1,0,0],[1,2],'Coupe transversale à X = 0 (axes Y/Z)')]:
    lines=trimesh.intersections.mesh_plane(m,normal,[0,0,0])[:,:,coords]
    draw.text((40,cy-155),title,fill='#193a32',font=font)
    for line in lines:
        xy=[(750+float(p[0])*10,cy-float(p[1])*10) for p in line]
        draw.line(xy,fill='#245b4a',width=1)
draw.text((40,620),'Surfaces du fichier reçu; ne représente pas les trajectoires d’impression.',fill='#555555',font=font)
im.save(out/'coupes-du-stl.png')
print(json.dumps({k:r[k] for k in ['extents_mm','reference_glb_v28_size_mm','connected_surface_components','zero_volume_components','bounding_box_full_PLA_mass_upper_bound_g']},indent=2))
print('Union diagnostique:',len(uc),'composantes; principaux volumes:',[round(p['volume_mm3'],5) for p in union_parts[:8]])
